from __future__ import annotations
import copy
import json
import copy
import re
import shutil
import os
import logging
import time
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock, get_ident
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

from docx import Document
from docx.text.paragraph import Paragraph
from docx.oxml.ns import qn
from docx.shared import Pt, Inches, Cm
from openpyxl import load_workbook
from openpyxl.worksheet.pagebreak import Break
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter, column_index_from_string
from pptx import Presentation
from pypdf import PdfReader

try:
    import fitz  # PyMuPDF, used to render scanned PDF pages for OCR
except Exception:  # pragma: no cover
    fitz = None

from .ocr_engine import capability as ocr_capability, extract_text_from_image
from .translation_engine import (
    TranslationClient,
    _canonicalize_technical_placeholders,
    capability as translation_capability,
)
from .conversion_engine import convert_outputs

ProgressCallback = Callable[[int, str, str], None]
LOGGER = logging.getLogger("document_automation.jobs")

# Progress telemetry must never block document processing. The actual persistence
# callback already owns a bounded queue; this extra single-worker handoff protects
# the processing thread from accidental synchronous database/control waits.
_PROGRESS_EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="job-progress")
_PROGRESS_LOCK = Lock()
_PROGRESS_LATEST: dict[int, tuple[ProgressCallback, int, str, str]] = {}

def _dispatch_progress(key: int) -> None:
    while True:
        with _PROGRESS_LOCK:
            item = _PROGRESS_LATEST.pop(key, None)
        if item is None:
            return
        callback, progress, step, message = item
        try:
            callback(progress, step, message)
        except Exception:
            LOGGER.exception("Non-blocking progress callback failed: step=%s", step)



def _replace_with_retry(source: Path, destination: Path, attempts: int = 12) -> None:
    """Atomically publish an output file despite transient Windows scanners/preview locks."""
    last_error: OSError | None = None
    for attempt in range(attempts):
        try:
            os.replace(source, destination)
            return
        except OSError as exc:
            last_error = exc
            time.sleep(min(0.75, 0.06 * (attempt + 1)))
    raise RuntimeError(f"输出文件暂时被系统占用，请关闭 Excel 预览后重试：{destination.name}") from last_error


def _unlink_with_retry(path: Path, attempts: int = 8) -> None:
    """Best-effort removal that does not let a Windows preview lock stall the job state machine."""
    if not path.exists():
        return
    last_error: OSError | None = None
    for attempt in range(attempts):
        try:
            path.unlink(missing_ok=True)
            return
        except OSError as exc:
            last_error = exc
            time.sleep(min(0.5, 0.05 * (attempt + 1)))
    LOGGER.warning("Could not remove locked temporary/output file %s: %s", path, last_error)


class _PerfTrace:
    def __init__(self, label: str, callback=None):
        self.label = label
        self.callback = callback
        self.started = time.perf_counter()
        self.last = self.started
        self.rows: list[tuple[str, float]] = []

    def mark(self, stage: str) -> float:
        now = time.perf_counter()
        elapsed = now - self.last
        self.last = now
        self.rows.append((stage, elapsed))
        LOGGER.info("PERF file=%s stage=%s elapsed=%.3fs total=%.3fs", self.label, stage, elapsed, now-self.started)
        return elapsed

    def summary(self) -> str:
        return "；".join(f"{name} {seconds:.1f}s" for name, seconds in self.rows)


_DELIVERY_FORBIDDEN_MARKERS = (
    "Cần xác nhận bản dịch", "Cần xác nhận", "待确认翻译",
    "待确认", "Translation pending", "Pending translation",
)


def _contains_forbidden_marker(value: str | None) -> bool:
    text = str(value or "")
    return any(marker.lower() in text.lower() for marker in _DELIVERY_FORBIDDEN_MARKERS)


def _valid_existing_target(value: str | None) -> bool:
    """Accept only clean, reusable target text from historical workbooks."""
    text = str(value or "").strip()
    if not text or _contains_forbidden_marker(text) or _CJK_RE.search(text):
        return False
    lowered = text.casefold()
    # Known V35/V36.0 mistranslations must enter repair mode rather than being
    # preserved forever as customer-approved text.
    poisoned = (
        "để qua một bên", "một bên", "sao lưu", "cắt chiều cao",
        "thang máy xe", "khối xả xe", "cho xe cấp liệu tại chỗ",
        "dòng xả xe", "máy quét máy trạm", "khóa trái với",
        "khóa phải với", "đai dưới", "đai tải",
    )
    if any(item in lowered for item in poisoned):
        return False
    return True

def _validate_xlsx_delivery_guard(path: Path) -> dict[str, int]:
    """Final customer-delivery guard for Excel packages.

    This guard is mandatory and is never exposed as a user-selectable option.
    It blocks review placeholders, broken OOXML packages and empty workbooks.
    Domain-specific untranslated checks are performed earlier while source and
    target cells are still paired, which avoids mistaking intentional bilingual
    source text, brand names or PLC codes for missed translations.
    """
    if not path.exists() or path.stat().st_size <= 0:
        raise RuntimeError("企业交付质量检查未通过：Excel 输出文件为空")
    with zipfile.ZipFile(path, "r") as archive:
        broken = archive.testzip()
        if broken is not None:
            raise RuntimeError(f"企业交付质量检查未通过：Excel 包损坏（{broken}）")
        names = archive.namelist()
        name_set = set(names)
        if "xl/workbook.xml" not in name_set:
            raise RuntimeError("企业交付质量检查未通过：缺少 Excel 工作簿结构")
        # sharedStrings.xml is optional in valid XLSX files. openpyxl may convert
        # all strings to inlineStr and legitimately remove it. Only reject the
        # package when worksheet cells still reference shared-string indexes.
        has_shared_refs = False
        for sheet_name in (n for n in names if n.startswith("xl/worksheets/") and n.endswith(".xml")):
            data = archive.read(sheet_name)
            if b't="s"' in data or b"t='s'" in data:
                has_shared_refs = True
                break
        if has_shared_refs and "xl/sharedStrings.xml" not in name_set:
            raise RuntimeError("企业交付质量检查未通过：工作表引用共享字符串，但缺少 xl/sharedStrings.xml")
        marker_hits = 0
        malformed_placeholder_hits = 0
        malformed_pattern = re.compile(
            r"%\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\)\s*(?:[-–—]\s*)+[diuoxXfFeEgGcs]"
        )
        for name in names:
            if not name.endswith((".xml", ".rels")):
                continue
            text = archive.read(name).decode("utf-8", errors="ignore")
            marker_hits += sum(text.count(marker) for marker in _DELIVERY_FORBIDDEN_MARKERS)
            malformed_placeholder_hits += len(malformed_pattern.findall(text))
        if marker_hits:
            raise RuntimeError(f"企业交付质量检查未通过：发现 {marker_hits} 个待确认/占位标记")
        if malformed_placeholder_hits:
            raise RuntimeError(
                f"企业交付质量检查未通过：发现 {malformed_placeholder_hits} 个损坏的 PLC/HMI 占位符"
            )
    return {"forbidden_markers": 0, "malformed_placeholders": 0, "package_errors": 0}




def _repair_xlsx_placeholder_corruption(path: Path) -> int:
    """Repair legacy placeholder corruption without rewriting every normal workbook.

    The former implementation rebuilt each XLSX unconditionally. On Windows this
    produced two full ZIP rewrites per file and could spend minutes waiting behind
    antivirus/preview locks. We now first inspect only XML parts that contain '%'
    and publish a rebuilt package only when an actual repair is required.
    """
    if not path.exists():
        return 0
    replacements: dict[str, bytes] = {}
    infos = []
    with zipfile.ZipFile(path, 'r') as archive:
        infos = list(archive.infolist())
        for info in infos:
            if not info.filename.endswith('.xml'):
                continue
            data = archive.read(info.filename)
            if b'%' not in data:
                continue
            text = data.decode('utf-8', errors='strict')
            fixed = _canonicalize_technical_placeholders(text)
            if fixed != text:
                replacements[info.filename] = fixed.encode('utf-8')
    if not replacements:
        return 0
    temp_path = path.with_suffix(path.suffix + '.placeholder-repair.tmp')
    _unlink_with_retry(temp_path)
    with zipfile.ZipFile(path, 'r') as archive, zipfile.ZipFile(
        temp_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=3
    ) as output:
        for info in infos:
            output.writestr(info, replacements.get(info.filename, archive.read(info.filename)))
    _replace_with_retry(temp_path, path)
    return len(replacements)

def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_plan(order: dict[str, Any]) -> list[dict[str, Any]]:
    services = order.get("services") or []
    steps: list[dict[str, Any]] = [
        {"id": "validate", "label": "Validate source files", "required": True},
        {"id": "analyze", "label": "Analyze document structure", "required": True},
    ]
    if "ocr" in services:
        steps.append({"id": "ocr", "label": "OCR scanned content", "required": True})
    if "translation" in services:
        steps.append({"id": "translation", "label": "AI automatic translation", "required": True})
    if "data_cleanup" in services:
        steps.append({"id": "cleanup", "label": "智能数据整理", "required": True})
    if "enterprise_analysis" in services:
        steps.append({"id": "analysis_report", "label": "企业数据分析", "required": True})
    if "conversion" in services:
        steps.append({"id": "conversion", "label": "Convert selected output formats", "required": True})
    if "layout_preserve" in services:
        steps.append({"id": "layout", "label": "Preserve or recover layout", "required": True})
    steps.append({"id": "quality", "label": "Validate processing quality", "required": True})
    steps.append({"id": "export", "label": "Generate delivery files", "required": True})
    if "manual_review" in services:
        steps.append({"id": "review", "label": "Manual quality review", "required": True})
    return steps


def _resolve_job_outcome(successful_output_count: int, failure_count: int, manual_review: bool = False) -> tuple[str, str]:
    """Return the single authoritative terminal state and user-facing message."""
    if successful_output_count <= 0:
        if failure_count > 0:
            return "failed", f"处理失败：0 个文件可交付，{failure_count} 项失败"
        return "failed", "处理失败：没有生成可交付文件"
    if failure_count > 0:
        return "partial_completed", f"部分完成：成功交付 {successful_output_count} 个文件，{failure_count} 项失败"
    if manual_review:
        return "quality_review", f"处理完成：{successful_output_count} 个文件等待人工验收"
    return "completed", f"处理完成：成功交付 {successful_output_count} 个文件"


def _update(callback: ProgressCallback | None, progress: int, step: str, message: str) -> None:
    if not callback:
        return
    # File-boundary control events stay synchronous so pause/stop is observed at
    # safe points. All ordinary UI telemetry is coalesced and dispatched away
    # from the document worker; a slow SQLite/UI callback can no longer add
    # minutes between sub-second XLSX stages.
    if message.endswith("开始处理文件") or "正在准备处理" in message:
        callback(progress, step, message)
        return
    key = id(callback)
    should_submit = False
    with _PROGRESS_LOCK:
        should_submit = key not in _PROGRESS_LATEST
        _PROGRESS_LATEST[key] = (callback, progress, step, message)
    if should_submit:
        _PROGRESS_EXECUTOR.submit(_dispatch_progress, key)
    if progress >= 100:
        # A terminal event must be observable before run_local_job returns.
        # Queue a barrier behind the single dispatcher so an older coalesced
        # event can never overwrite 100% in the UI after completion.
        _PROGRESS_EXECUTOR.submit(lambda: None).result(timeout=10)


def _needs_multiline_layout(layout: str, changed_values: Iterable[str]) -> bool:
    """Return True only when this run generated vertical multiline bilingual cells.

    Existing bilingual source text must not trigger a full XLSX OOXML rescan.
    That historical behavior made cache-hit files spend minutes at 36%% even
    when zero cells changed.
    """
    if layout != "vertical":
        return False
    return any("\n" in str(value or "") for value in changed_values)


def _translate_pptx(source: Path, destination: Path, client: TranslationClient, callback: ProgressCallback | None) -> int:
    presentation = Presentation(source)
    translated = 0
    total = max(1, len(presentation.slides))
    for slide_index, slide in enumerate(presentation.slides, start=1):
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False):
                for paragraph in shape.text_frame.paragraphs:
                    original = "".join(run.text for run in paragraph.runs) or paragraph.text
                    if original.strip():
                        value = client.translate(original)
                        if paragraph.runs:
                            paragraph.runs[0].text = value
                            for run in paragraph.runs[1:]:
                                run.text = ""
                        else:
                            paragraph.text = value
                        translated += 1
            if getattr(shape, "has_table", False):
                for row in shape.table.rows:
                    for cell in row.cells:
                        for paragraph in cell.text_frame.paragraphs:
                            original = "".join(run.text for run in paragraph.runs) or paragraph.text
                            if original.strip():
                                value = client.translate(original)
                                if paragraph.runs:
                                    paragraph.runs[0].text = value
                                    for run in paragraph.runs[1:]:
                                        run.text = ""
                                else:
                                    paragraph.text = value
                                translated += 1
        _update(callback, 35 + int(slide_index / total * 45), "translation", f"Translated PowerPoint slide {slide_index}/{total}")
    presentation.save(destination)
    return translated


TARGET_SUFFIXES = {
    "zh": "zh-CN", "zh_tw": "zh-TW", "vi": "vi", "en": "en",
    "ja": "ja", "ko": "ko", "th": "th", "fr": "fr", "de": "de",
    "es": "es", "pt": "pt", "ru": "ru", "ar": "ar",
}


def _target_suffix(client: TranslationClient | None) -> str:
    if client is None:
        return "processed"
    raw = str(getattr(client, "target_language_code", "") or "").strip().lower()
    if not raw:
        raw = str(getattr(client, "target_language", "") or "").strip().lower()
    return TARGET_SUFFIXES.get(raw, re.sub(r"[^a-z0-9-]+", "-", raw).strip("-") or "translated")


def _paragraph_text(paragraph) -> str:
    """Return all visible text, including text nested in hyperlinks/text boxes."""
    nodes = paragraph._p.xpath('.//w:t')
    xml_text = ''.join(node.text or '' for node in nodes)
    return xml_text or paragraph.text or ''


def _preferred_font_for_target(target_code: str) -> str | None:
    code = (target_code or "").lower()
    if code in {"zh", "zh_tw"}:
        return "Microsoft YaHei"
    if code == "ja":
        return "Yu Gothic"
    if code == "ko":
        return "Malgun Gothic"
    if code in {"ar"}:
        return "Arial"
    return None


def _apply_target_font(run, target_code: str) -> None:
    """Attach a real installed font and remove theme overrides that cause □ glyphs."""
    font_name = _preferred_font_for_target(target_code)
    if not font_name:
        return
    run.font.name = font_name
    r_pr = run._element.get_or_add_rPr()
    r_fonts = r_pr.rFonts
    if r_fonts is None:
        r_fonts = r_pr.get_or_add_rFonts()
    for attr in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):
        key = qn(f"w:{attr}")
        if key in r_fonts.attrib:
            del r_fonts.attrib[key]
    for attr in ("eastAsia", "ascii", "hAnsi", "cs"):
        r_fonts.set(qn(f"w:{attr}"), font_name)
    r_pr.set(qn("w:hint"), "eastAsia")


def _configure_document_fonts(document, target_code: str) -> None:
    """Set CJK-compatible defaults at document and style level for Word and WPS."""
    font_name = _preferred_font_for_target(target_code)
    if not font_name:
        return
    for style_name in ("Normal", "Title", "Subtitle", "Heading 1", "Heading 2", "Heading 3"):
        try:
            style = document.styles[style_name]
        except KeyError:
            continue
        style.font.name = font_name
        r_pr = style.element.get_or_add_rPr()
        r_fonts = r_pr.rFonts
        if r_fonts is None:
            r_fonts = r_pr.get_or_add_rFonts()
        for attr in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):
            key = qn(f"w:{attr}")
            if key in r_fonts.attrib:
                del r_fonts.attrib[key]
        for attr in ("eastAsia", "ascii", "hAnsi", "cs"):
            r_fonts.set(qn(f"w:{attr}"), font_name)


def _replace_paragraph_text(paragraph, value: str, target_code: str = "") -> None:
    """Replace text without flattening paragraph-level layout or non-text XML.

    Word frequently stores a sentence across several runs and may place text inside
    hyperlinks or text boxes. Updating the underlying ``w:t`` nodes preserves the
    surrounding run formatting, hyperlinks, drawings, bookmarks and field codes.
    """
    text_nodes = list(paragraph._p.xpath('.//w:t'))
    if text_nodes:
        anchor = next((node for node in text_nodes if node.text), text_nodes[0])
        for node in text_nodes:
            node.text = value if node is anchor else ''
        # Apply an East-Asian-capable font to the run containing the anchor node.
        parent = anchor.getparent()
        for run in paragraph.runs:
            if run._element is parent:
                _apply_target_font(run, target_code)
                break
    else:
        run = paragraph.add_run(value)
        _apply_target_font(run, target_code)


def _validate_docx(path: Path) -> dict[str, Any]:
    """Reopen and inspect the generated DOCX before it is delivered."""
    document = Document(path)
    text_blocks = []
    for paragraph in _iter_docx_paragraphs(document):
        text = _paragraph_text(paragraph).strip()
        if text:
            text_blocks.append(text)
    joined = "\n".join(text_blocks)
    bad_chars = {"\ufffd": joined.count("\ufffd"), "\u25a1": joined.count("\u25a1")}
    bad_chars = {key: value for key, value in bad_chars.items() if value}
    if bad_chars:
        raise RuntimeError(f"Generated DOCX contains invalid replacement characters: {bad_chars}")
    return {
        "paragraphs": len(document.paragraphs),
        "tables": len(document.tables),
        "sections": len(document.sections),
        "text_blocks": len(text_blocks),
        "characters": len(joined),
        "invalid_character_count": 0,
    }

def _iter_docx_paragraphs(document):
    """Yield each physical DOCX paragraph exactly once.

    ``id(lxml_element)`` is not a safe de-duplication key because lxml may create
    short-lived Python wrappers for the same XML node and may later reuse their
    object ids.  That caused linked headers/footers to be counted twice in the
    source and then fewer times after reopening the output, producing false
    errors such as ``source had 13 text blocks but output has 11``.

    A stable key is the OOXML part name plus the node's absolute XPath inside
    that part.  It also preserves distinct paragraphs that happen to contain the
    same text.
    """
    seen: set[tuple[str, str]] = set()

    def emit(root, parent, part_name: str):
        tree = root.getroottree()
        for element in root.xpath('.//w:p'):
            key = (part_name, tree.getpath(element))
            if key in seen:
                continue
            seen.add(key)
            yield Paragraph(element, parent)

    body_part = str(getattr(document.part, 'partname', '/word/document.xml'))
    yield from emit(document.element.body, document, body_part)

    for section in document.sections:
        containers = (
            section.header, section.footer,
            section.first_page_header, section.first_page_footer,
            section.even_page_header, section.even_page_footer,
        )
        for container in containers:
            part_name = str(getattr(container.part, 'partname', ''))
            yield from emit(container._element, container, part_name)


def _translate_docx(source: Path, destination: Path, client: TranslationClient, callback: ProgressCallback | None) -> dict[str, Any]:
    document = Document(source)
    _configure_document_fonts(document, client.target_language_code)
    paragraphs = list(_iter_docx_paragraphs(document))
    translatable = [p for p in paragraphs if _paragraph_text(p).strip()]
    total = max(1, len(translatable))
    translated = 0
    skipped = 0
    for index, paragraph in enumerate(translatable, start=1):
        original = _paragraph_text(paragraph)
        value = client.translate(original)
        # A provider must never be allowed to erase a visible source block.
        # Preserve the original and report it as skipped when the response is blank.
        if not str(value or '').strip():
            value = original
        if value != original:
            _replace_paragraph_text(paragraph, value, client.target_language_code)
            translated += 1
        else:
            skipped += 1
        if index % 5 == 0 or index == total:
            _update(callback, 35 + int(index / total * 45), "translation", f"Translated Word content {index}/{total}")

    # Preserve the original document package and add traceable metadata.
    document.core_properties.comments = "Translated by Document Automation AI"
    document.save(destination)
    validation = _validate_docx(destination)
    if validation["text_blocks"] != len(translatable):
        raise RuntimeError(
            f"DOCX validation failed: source had {len(translatable)} unique text blocks but output has "
            f"{validation['text_blocks']}."
        )
    return {
        "translated_items": translated,
        "skipped_items": skipped,
        "source_text_blocks": len(translatable),
        "translation_coverage": round(translated / max(1, len(translatable)) * 100, 2),
        "validation": validation,
    }


def _excel_column_number(ref: str) -> int:
    match = re.match(r"([A-Z]+)", ref or "")
    if not match:
        return 1
    value = 0
    for ch in match.group(1):
        value = value * 26 + ord(ch) - 64
    return value


def _excel_column_name(number: int) -> str:
    number = max(1, int(number))
    result = []
    while number:
        number, remainder = divmod(number - 1, 26)
        result.append(chr(65 + remainder))
    return "".join(reversed(result))


def _prepare_xlsx_for_processing(source: Path, callback: ProgressCallback | None = None, step: str = "translation") -> tuple[Path, Path | None]:
    """Create a compact temporary XLSX when a worksheet contains millions of empty styled cells.

    Some customer workbooks declare A1:XFDxxxx and store one self-closing ``<c/>``
    node for nearly every empty formatted cell.  openpyxl must materialize those
    nodes and can appear frozen for many minutes.  The compact copy removes only
    empty cell nodes from pathological sheets, keeps all cells containing values,
    formulas or inline strings, and updates the worksheet dimension.  The source
    file is never modified.
    """
    threshold = max(20 * 1024 * 1024, int(os.getenv("XLSX_XML_COMPACT_THRESHOLD_MB", "80")) * 1024 * 1024)
    try:
        with zipfile.ZipFile(source, "r") as archive:
            worksheet_infos = [info for info in archive.infolist() if info.filename.startswith("xl/worksheets/") and info.filename.endswith(".xml")]
            pathological = [info for info in worksheet_infos if info.file_size >= threshold]
            if not pathological:
                return source, None
            _update(callback, 5, step, f"检测到超大 Excel 工作表，正在压缩 {len(pathological)} 个异常空白区域")
            temp_handle = tempfile.NamedTemporaryFile(prefix="docai_compact_", suffix=".xlsx", delete=False)
            temp_path = Path(temp_handle.name)
            temp_handle.close()
            with zipfile.ZipFile(temp_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
                for info in archive.infolist():
                    data = archive.read(info.filename)
                    if info in pathological:
                        before = len(data)
                        # Remove only truly empty self-closing cells. Cells with
                        # values/formulas/inline strings are never self-closing.
                        data = re.sub(br"<c\b[^>]*/>", b"", data)
                        refs = re.findall(br"<c\b[^>]*\br=\"([A-Z]+[0-9]+)\"[^>]*>", data)
                        if refs:
                            max_row = 1
                            max_col = 1
                            for raw_ref in refs:
                                ref = raw_ref.decode("ascii", "ignore")
                                row_match = re.search(r"(\d+)$", ref)
                                if row_match:
                                    max_row = max(max_row, int(row_match.group(1)))
                                max_col = max(max_col, _excel_column_number(ref))
                            dimension = f'A1:{_excel_column_name(max_col)}{max_row}'.encode("ascii")
                            data = re.sub(br'<dimension\s+ref="[^"]+"\s*/>', b'<dimension ref="' + dimension + b'"/>', data, count=1)
                        LOGGER.info("Compacted worksheet XML: file=%s sheet=%s before=%s after=%s", source.name, info.filename, before, len(data))
                    output.writestr(info, data)
            _update(callback, 10, step, "异常空白区域压缩完成，正在打开实际数据")
            return temp_path, temp_path
    except Exception:
        LOGGER.exception("Failed to compact pathological workbook: %s", source)
        raise




_CJK_RE = re.compile(r"[\u3400-\u9fff]")
_TARGET_WORD_RE = re.compile(r"[A-Za-zÀ-ỹ]+(?:[ '\-][A-Za-zÀ-ỹ]+)*")
_TECH_TOKEN_RE = re.compile(r"^(?:[A-Z]{1,8}\d+[A-Za-z0-9_.:/\-]*|[A-Za-z0-9]+(?:_[A-Za-z0-9]+)+|[A-Z]{2,}[A-Z0-9_.:/\-]*)$")
_TECH_PREFIX_RE = re.compile(
    r"^\s*((?:[A-Z]{1,8}\d+[A-Za-z0-9_.:/\-]*|[A-Za-z0-9]+(?:_[A-Za-z0-9]+)+|[A-Z]{2,}[A-Z0-9_.:/\-]*))"
    r"(?:\s*[|｜]\s*|\s+)(.+)$",
    re.S,
)


def _split_existing_bilingual_text(text: str) -> tuple[str, str] | None:
    """Return the Chinese/source side and existing Latin translation.

    Handles explicit separators, line breaks and historical glued output while
    ignoring PLC/HMI identifiers such as X001, SD0 and Tip0_Title.
    """
    value = str(text or "").strip()
    if not _CJK_RE.search(value):
        return None

    # Prefer explicit separators because they are deterministic.
    for sep in ("——", "—", "\n", " - "):
        if sep in value:
            left, right = value.split(sep, 1)
            if _CJK_RE.search(left) and re.search(r"[A-Za-zÀ-ỹ]", right):
                return left.strip(" \t\r\n:/—-–"), right.strip(" \t\r\n:/—-–")

    last_cjk = max((m.end() for m in _CJK_RE.finditer(value)), default=0)
    for match in _TARGET_WORD_RE.finditer(value, pos=last_cjk):
        token = match.group(0).strip()
        compact = token.replace(" ", "")
        if not token or _TECH_TOKEN_RE.fullmatch(compact):
            continue
        if not (re.search(r"[a-zà-ỹ]", token) or re.search(r"[À-ỹ]", token)):
            continue
        source = value[:match.start()].rstrip(" \t\r\n:/—-–")
        target = value[match.start():].strip(" \t\r\n:/—-–")
        if source and target:
            return source, target
    return None


def _split_technical_prefix(text: str) -> tuple[str, str]:
    """Split a leading PLC/HMI address or identifier from Chinese text."""
    value = str(text or "").strip().replace("｜", "|")
    match = _TECH_PREFIX_RE.match(value)
    if not match:
        return "", value.strip(" |\t\r\n")
    prefix, body = match.group(1).strip(), match.group(2).strip(" |\t\r\n")
    return prefix, body


def _extract_chinese_translation_unit(text: str) -> str:
    """Return the complete translatable body while preserving engineering syntax.

    V30.5.6 kept only contiguous Chinese character groups.  A label such as
    ``气缸IO输入_原点`` therefore became ``气缸 输入 原点`` before it reached the
    provider, losing the IO/underscore context and causing many mixed PLC labels
    to be echoed or skipped.  Keep the complete description and remove only the
    protected leading PLC/HMI address.
    """
    existing = _split_existing_bilingual_text(text)
    source_side = existing[0] if existing else str(text or "")
    _, body = _split_technical_prefix(source_side)
    body = re.sub(r"\s+", " ", body.replace("｜", "|")).strip(" |\t\r\n")
    return body if _CJK_RE.search(body) else ""


def _dedupe_technical_code(text: str, prefix: str) -> str:
    value = str(text or "").strip()
    if not prefix:
        return value
    # Remove duplicate PLC/HMI identifiers from the body/ending while preserving
    # one protected leading identifier in the final rendered cell.
    value = re.sub(rf"(?<![A-Za-z0-9_]){re.escape(prefix)}(?![A-Za-z0-9_])", " ", value, flags=re.I)
    return re.sub(r"\s+", " ", value).strip(" \t\r\n:/—-–")

def _canonicalize_vi_terms(value: str) -> str:
    text = str(value or "").strip()
    replacements = {
        "một bên": "Dự phòng",
        "để qua một bên": "Dự phòng",
        "sao lưu": "Dự phòng",
        "sóng mang": "Khay",
        "phương tiện": "Khay",
        "hạ tốc": "Giảm tốc",
        "về zero": "Về gốc",
        "về không": "Về gốc",
    }
    for bad, good in replacements.items():
        text = re.sub(rf"(?i)(?<![A-Za-zÀ-ỹ]){re.escape(bad)}(?![A-Za-zÀ-ỹ])", good, text)
    return re.sub(r"\s+", " ", text).strip()

def _clean_translation_candidate(source: str, translated: str) -> str:
    candidate = str(translated or "").strip()
    candidate_pair = _split_existing_bilingual_text(candidate)
    if candidate_pair:
        candidate = candidate_pair[1]
    unit = _extract_chinese_translation_unit(source)
    for removable in (str(source or "").strip(), unit):
        if removable:
            candidate = candidate.replace(removable, " ")
    prefix, _ = _split_technical_prefix(source)
    candidate = _dedupe_technical_code(candidate.replace("|", " "), prefix)
    candidate = _canonicalize_vi_terms(candidate)
    candidate = re.sub(r"\s+", " ", candidate).strip(" \t\r\n:/—-–")
    return candidate


def _resolve_bilingual_layout(layout: str | None, file_type: str = "xlsx") -> str:
    """Normalize UI/API layout values to a stable processing rule."""
    value = str(layout or "auto").strip().lower().replace("_", "-")
    aliases = {
        "horizontal": "inline",
        "same-line": "inline",
        "side-by-side": "columns",
        "single-language": "target-only",
        "target-only": "target-only",
        "bilingual-paired": "inline",
        "publishing": "vertical",
        "industrial": "columns",
    }
    value = aliases.get(value, value)
    if value == "auto":
        return "inline" if file_type in {"xlsx", "xls", "csv", "table"} else "vertical"
    return value if value in {"inline", "vertical", "columns", "target-only"} else "inline"


def _normalize_bilingual_value(source: str, translated: str, layout: str | None = None, options: dict[str, Any] | None = None) -> str:
    """Create bilingual content while preserving PLC/HMI identifiers."""
    existing = _split_existing_bilingual_text(source)
    source_side = existing[0] if existing else str(source or "").strip()
    prefix, body = _split_technical_prefix(source_side)
    body = _dedupe_technical_code(body, prefix)
    candidate = _clean_translation_candidate(source, translated)
    if not candidate and existing:
        candidate = existing[1].strip()
    body = body.replace("|", " ").strip()
    source_clean = " ".join(part for part in (prefix, body) if part).strip()
    legacy_auto = layout is None
    mode = _resolve_bilingual_layout(layout or "vertical", "xlsx")
    options = options or {}
    if not candidate:
        return source_clean
    if legacy_auto and not prefix:
        return f"{body} —— {candidate}" if body else candidate
    if mode == "target-only":
        return " ".join(part for part in (prefix, candidate) if part).strip()
    if mode == "vertical":
        lines = [part for part in (prefix, body, candidate) if part]
        if str(options.get("vertical_order") or "source-first") == "target-first":
            lines = [candidate, *[part for part in (prefix, body) if part]]
        return "\n".join(lines)
    if mode == "columns":
        return " ".join(part for part in (prefix, candidate) if part).strip()
    inline_style = str(options.get("inline_style") or "dash")
    if inline_style == "slash":
        return f"{source_clean} / {candidate}" if source_clean else candidate
    if inline_style == "parentheses":
        return f"{source_clean}（{candidate}）" if source_clean else candidate
    if inline_style == "pipe":
        return f"{source_clean} | {candidate}" if source_clean else candidate
    return f"{source_clean} - {candidate}" if source_clean else candidate



def _apply_excel_side_by_side_layout_impl(
    workbook_path: Path,
    target_mapping: dict[str, str],
    options: dict[str, Any],
) -> int:
    """Create adjacent source/target columns in one linear worksheet pass.

    The previous implementation called ``ws.insert_cols`` once for every source
    column. On large, heavily styled PLC/HMI workbooks that repeatedly shifted
    the whole worksheet and could exceed the 90-second subprocess watchdog.

    This implementation first determines which columns actually require a new
    blank neighbour, then moves every existing cell at most once. Existing blank
    neighbour columns are reused, matching the former behaviour.
    """
    if not target_mapping:
        return 0

    from bisect import bisect_left, bisect_right
    from openpyxl.cell.cell import MergedCell
    from openpyxl.utils.cell import range_boundaries

    wb = load_workbook(workbook_path, data_only=False)
    style = str(options.get("columns_style") or "address-with-text")
    address_mode = str(options.get("address_mode") or "keep")
    changed = 0
    layout_started = time.perf_counter()

    try:
        for ws in wb.worksheets:
            source_columns: dict[int, list[tuple[int, str, str]]] = {}

            # Iterate only materialised cells. ``iter_rows`` walks the declared
            # worksheet rectangle and can visit millions of empty styled cells.
            for (row_num, col_num), cell in list(ws._cells.items()):
                if isinstance(cell, MergedCell) or not isinstance(cell.value, str):
                    continue
                original = cell.value.strip()
                target = target_mapping.get(original)
                if not target:
                    continue
                source_columns.setdefault(col_num, []).append(
                    (row_num, original, target)
                )

            if not source_columns:
                continue

            source_col_numbers = sorted(source_columns)

            # Preserve the old rule: create a new column only when the immediate
            # neighbour contains data in one of the translated rows. Otherwise
            # reuse that existing blank neighbour.
            insertion_after: list[int] = []
            for source_col in source_col_numbers:
                target_col = source_col + 1
                occupied = any(
                    (
                        ws._cells.get((row_num, target_col)) is not None
                        and ws._cells[(row_num, target_col)].value not in (None, "")
                    )
                    for row_num, _, _ in source_columns[source_col]
                )
                if occupied:
                    insertion_after.append(source_col)

            insertion_after.sort()

            def shifted_col(old_col: int) -> int:
                # Insertions occur *after* their source column, therefore only
                # insertions strictly to the left move the old column.
                return old_col + bisect_left(insertion_after, old_col)

            # Unmerge before moving cells so MergedCell placeholders cannot
            # overwrite real cells. Ranges are restored after coordinates move.
            old_merged_ranges = [str(item) for item in ws.merged_cells.ranges]
            for merged_range in old_merged_ranges:
                ws.unmerge_cells(merged_range)

            # Move existing cells once, right-to-left, to avoid collisions.
            # Worksheet._move_cell preserves value, style, comment and hyperlink.
            for row_num, old_col in sorted(
                list(ws._cells.keys()),
                key=lambda item: (item[1], item[0]),
                reverse=True,
            ):
                shift = bisect_left(insertion_after, old_col)
                if shift:
                    ws._move_cell(
                        row_num,
                        old_col,
                        row_offset=0,
                        col_offset=shift,
                        translate=False,
                    )

            # Shift explicit column dimensions once. Default-width columns do not
            # appear in this mapping and need no work.
            old_dimensions = list(ws.column_dimensions.items())
            ws.column_dimensions.clear()
            for old_letter, dimension in old_dimensions:
                try:
                    old_col = column_index_from_string(old_letter)
                except (TypeError, ValueError):
                    # Preserve unusual/custom dimension keys unchanged.
                    ws.column_dimensions[old_letter] = dimension
                    continue
                new_col = shifted_col(old_col)
                new_letter = get_column_letter(new_col)
                dimension.index = new_letter
                if getattr(dimension, "min", None) is not None:
                    dimension.min = shifted_col(int(dimension.min))
                if getattr(dimension, "max", None) is not None:
                    dimension.max = shifted_col(int(dimension.max))
                ws.column_dimensions[new_letter] = dimension

            # Restore merged ranges with their shifted coordinates. Insertions
            # located inside a merge expand its right edge, matching Excel's
            # visible layout more closely than leaving stale coordinates.
            for merged_range in old_merged_ranges:
                min_col, min_row, max_col, max_row = range_boundaries(merged_range)
                new_min_col = min_col + bisect_left(insertion_after, min_col)
                new_max_col = max_col + bisect_right(insertion_after, max_col)
                ws.merge_cells(
                    start_row=min_row,
                    start_column=new_min_col,
                    end_row=max_row,
                    end_column=new_max_col,
                )

            # Populate the target columns after all structural movement is done.
            for old_source_col in source_col_numbers:
                source_col = shifted_col(old_source_col)
                target_col = source_col + 1
                source_letter = get_column_letter(source_col)
                target_letter = get_column_letter(target_col)
                ws.column_dimensions[target_letter].width = (
                    ws.column_dimensions[source_letter].width
                )

                for row_num, original, target in source_columns[old_source_col]:
                    src_cell = ws.cell(row_num, source_col)
                    dst_cell = ws.cell(row_num, target_col)

                    existing_pair = _split_existing_bilingual_text(original)
                    source_value = existing_pair[0] if existing_pair else original
                    prefix, source_body = _split_technical_prefix(source_value)
                    source_body = _dedupe_technical_code(source_body, prefix)
                    _, target_body = _split_technical_prefix(target)
                    target_body = _canonicalize_vi_terms(
                        _dedupe_technical_code(target_body, prefix)
                    )

                    if address_mode == "hide" or style == "text-only":
                        src_cell.value = source_body or original
                        dst_cell.value = target_body or target
                    else:
                        src_cell.value = " ".join(
                            part for part in (prefix, source_body) if part
                        ).strip()
                        dst_cell.value = " ".join(
                            part for part in (prefix, target_body or target) if part
                        ).strip()

                    if src_cell.has_style:
                        dst_cell._style = copy.copy(src_cell._style)
                    dst_cell.number_format = src_cell.number_format
                    dst_cell.alignment = copy.copy(src_cell.alignment)
                    dst_cell.font = copy.copy(src_cell.font)
                    dst_cell.fill = copy.copy(src_cell.fill)
                    dst_cell.border = copy.copy(src_cell.border)
                    dst_cell.protection = copy.copy(src_cell.protection)
                    if src_cell.comment is not None:
                        dst_cell.comment = copy.copy(src_cell.comment)
                    changed += 1

        token = f"{os.getpid()}_{get_ident()}_{time.time_ns()}"
        temp = workbook_path.with_name(
            f".{workbook_path.stem}.{token}.columns{workbook_path.suffix}"
        )
        _unlink_with_retry(temp, attempts=2)

        try:
            wb.save(temp)
        finally:
            wb.close()

        try:
            _validate_xlsx_delivery_guard(temp)
            _replace_with_retry(temp, workbook_path, attempts=4)
        finally:
            _unlink_with_retry(temp, attempts=2)

        LOGGER.info(
            "Excel side-by-side linear layout completed: file=%s changed=%s elapsed=%.3fs",
            workbook_path.name,
            changed,
            time.perf_counter() - layout_started,
        )
        return changed
    except Exception:
        try:
            wb.close()
        except Exception:
            pass
        raise

def _debug_step(file_name: str, step: str, state: str, started: float | None = None, **extra: Any) -> None:
    elapsed = ""
    if started is not None:
        elapsed = f" elapsed={time.perf_counter() - started:.3f}s"
    details = " ".join(f"{key}={value}" for key, value in extra.items())
    LOGGER.info(
        "PIPELINE file=%s step=%s state=%s thread=%s%s%s",
        file_name,
        step,
        state,
        get_ident(),
        elapsed,
        f" {details}" if details else "",
    )


def _apply_excel_side_by_side_layout(workbook_path: Path, target_mapping: dict[str, str], options: dict[str, Any]) -> int:
    """Run the expensive openpyxl column layout in an isolated process.

    V40.5 debug/stability change: openpyxl column insertion can block inside a
    worker thread without raising. Isolating it gives us a hard timeout and a
    precise diagnostic trail instead of leaving the whole order at 36% forever.
    """
    if not target_mapping:
        return 0
    import json
    import subprocess
    import sys
    token = f"{os.getpid()}_{get_ident()}_{time.time_ns()}"
    request_path = workbook_path.with_name(f".{workbook_path.stem}.{token}.columns.json")
    result_path = workbook_path.with_name(f".{workbook_path.stem}.{token}.columns.result.json")
    payload = {
        "workbook_path": str(workbook_path),
        "target_mapping": target_mapping,
        "options": options,
        "result_path": str(result_path),
    }
    request_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    timeout_seconds = max(15, min(300, int(os.getenv("XLSX_COLUMNS_TIMEOUT_SECONDS", "90"))))
    started = time.perf_counter()
    _debug_step(workbook_path.name, "columns_subprocess", "ENTER", started, items=len(target_mapping), timeout=timeout_seconds)
    worker_script = Path(__file__).with_name("xlsx_columns_worker.py")
    try:
        completed = subprocess.run(
            [sys.executable, str(worker_script), str(request_path)],
            cwd=str(Path(__file__).resolve().parents[3]),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        _debug_step(workbook_path.name, "columns_subprocess", "RETURN", started, returncode=completed.returncode)
        if completed.stdout.strip():
            LOGGER.info("COLUMNS_WORKER stdout=%s", completed.stdout.strip()[-4000:])
        if completed.stderr.strip():
            LOGGER.warning("COLUMNS_WORKER stderr=%s", completed.stderr.strip()[-4000:])
        if completed.returncode != 0:
            raise RuntimeError(f"Excel 左右分列子进程失败（code={completed.returncode}）：{completed.stderr.strip()[-1000:]}")
        if not result_path.exists():
            raise RuntimeError("Excel 左右分列子进程未返回结果文件")
        result = json.loads(result_path.read_text(encoding="utf-8"))
        if not result.get("ok"):
            raise RuntimeError(str(result.get("error") or "Excel 左右分列失败"))
        changed = int(result.get("changed") or 0)
        _debug_step(workbook_path.name, "columns_subprocess", "FINISHED", started, changed=changed)
        return changed
    except subprocess.TimeoutExpired as exc:
        _debug_step(workbook_path.name, "columns_subprocess", "TIMEOUT", started, timeout=timeout_seconds)
        raise RuntimeError(f"Excel 左右分列处理超过 {timeout_seconds} 秒，已强制终止，避免任务永久停在36%") from exc
    finally:
        _unlink_with_retry(request_path, attempts=2)
        _unlink_with_retry(result_path, attempts=2)

def _apply_excel_multiline_layout(workbook_path: Path) -> None:
    """Enable wrapping and readable row heights for generated multiline cells.

    The update is performed directly in OOXML to avoid openpyxl rewriting the
    workbook. Only cells that contain generated line breaks receive a cloned
    wrapped style; all other workbook structure and styling stays untouched.
    """
    ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    with zipfile.ZipFile(workbook_path, "r") as src:
        payload = {info.filename: src.read(info.filename) for info in src.infolist()}
        infos = list(src.infolist())

    multiline_shared: dict[int, int] = {}
    shared_name = "xl/sharedStrings.xml"
    if shared_name in payload:
        shared_root = ET.fromstring(payload[shared_name])
        for idx, item in enumerate(shared_root.findall(ns + "si")):
            text = "".join(node.text or "" for node in item.iter(ns + "t"))
            if "\n" in text:
                multiline_shared[idx] = max(2, text.count("\n") + 1)
            elif " —— " in text:
                multiline_shared[idx] = 2

    styles_name = "xl/styles.xml"
    if styles_name not in payload:
        return
    styles_root = ET.fromstring(payload[styles_name])
    cell_xfs = styles_root.find(ns + "cellXfs")
    if cell_xfs is None:
        return

    from copy import deepcopy
    wrapped_style_by_key: dict[tuple[int, int], int] = {}

    def wrapped_style(style_id: int, line_count: int) -> int:
        key = (style_id, min(3, line_count))
        if key in wrapped_style_by_key:
            return wrapped_style_by_key[key]
        base = list(cell_xfs)[style_id] if 0 <= style_id < len(cell_xfs) else list(cell_xfs)[0]
        clone = deepcopy(base)
        alignment = clone.find(ns + "alignment")
        if alignment is None:
            alignment = ET.SubElement(clone, ns + "alignment")
        alignment.set("wrapText", "1")
        alignment.set("vertical", "center")
        clone.set("applyAlignment", "1")
        cell_xfs.append(clone)
        new_id = len(cell_xfs) - 1
        wrapped_style_by_key[key] = new_id
        return new_id

    changed_sheets: dict[str, ET.Element] = {}
    for name, data in list(payload.items()):
        if not (name.startswith("xl/worksheets/") and name.endswith(".xml")):
            continue
        root = ET.fromstring(data)
        dirty = False
        for row in root.iter(ns + "row"):
            row_lines = 1
            for cell in row.findall(ns + "c"):
                lines = 1
                if cell.get("t") == "s":
                    value_node = cell.find(ns + "v")
                    if value_node is not None and value_node.text and value_node.text.isdigit():
                        lines = multiline_shared.get(int(value_node.text), 1)
                elif cell.get("t") == "inlineStr":
                    text = "".join(node.text or "" for node in cell.iter(ns + "t"))
                    lines = max(1, text.count("\n") + 1)
                    if lines == 1 and " —— " in text:
                        lines = 2
                if lines > 1:
                    old_style = int(cell.get("s", "0") or 0)
                    cell.set("s", str(wrapped_style(old_style, lines)))
                    row_lines = max(row_lines, lines)
                    dirty = True
            if row_lines > 1:
                current = float(row.get("ht", "0") or 0)
                target = 34.0 if row_lines == 2 else 48.0
                row.set("ht", f"{max(current, target):g}")
                row.set("customHeight", "1")
        if dirty:
            changed_sheets[name] = root

    if not changed_sheets:
        return
    cell_xfs.set("count", str(len(cell_xfs)))
    payload[styles_name] = ET.tostring(styles_root, encoding="utf-8", xml_declaration=True)
    for name, root in changed_sheets.items():
        payload[name] = ET.tostring(root, encoding="utf-8", xml_declaration=True)

    temp = workbook_path.with_suffix(workbook_path.suffix + ".layout.tmp")
    _unlink_with_retry(temp)
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as out:
        for info in infos:
            out.writestr(info, payload[info.filename])
    _replace_with_retry(temp, workbook_path)




def _target_only_translation_client(client: TranslationClient, target_code: str) -> TranslationClient:
    """Reuse one target-only client per batch instead of rebuilding settings/cache per file."""
    cache = getattr(client, "_target_only_clients", None)
    if cache is None:
        cache = {}
        setattr(client, "_target_only_clients", cache)
    existing = cache.get(target_code)
    if existing is not None:
        return existing
    created = TranslationClient(
        source_language=getattr(client, "source_language_code", "auto"),
        target_language=target_code,
    )
    cache[target_code] = created
    return created

def _translate_reconstructed_xlsx(source: Path, destination: Path, client: TranslationClient, callback: ProgressCallback | None) -> int | None:
    """Fill all dedicated target-language columns in reconstructed workbooks.

    Fixed automation terminology is served from the embedded glossary first;
    only unknown phrases are sent to the configured translation provider.
    """
    try:
        wb = load_workbook(source, data_only=False)
    except Exception:
        return None
    try:
        if '文档概览' not in wb.sheetnames or 'PLC输入信号' not in wb.sheetnames:
            return None
        target_code = getattr(client, 'target_language_code', '')
        if target_code not in {'zh-vi','zh-en'}:
            return None
        target_label = '越南语' if target_code == 'zh-vi' else '英语'
        pairs=[]; sources=[]; seen=set()
        explicit_pairs={
            'PLC输入信号':[(3,4),(5,6),(7,8)],
            '设备清单':[(1,2),(4,5),(6,7),(8,9)],
            '气缸IO配置':[(2,3),(6,7),(8,9),(12,13)],
            '工位结构':[(2,3),(5,6),(7,8)],
            '操作提示':[(2,3),(5,6)],
        }
        for sheet_name,col_pairs in explicit_pairs.items():
            if sheet_name not in wb.sheetnames: continue
            ws=wb[sheet_name]
            for src_col,dst_col in col_pairs:
                if src_col>ws.max_column or dst_col>ws.max_column: continue
                for row in range(2,ws.max_row+1):
                    text=_clean_reconstructed_value(ws.cell(row,src_col).value)
                    if not text or not _CJK_RE.search(text): continue
                    existing=_clean_reconstructed_value(ws.cell(row,dst_col).value)
                    # English output must overwrite legacy Vietnamese seed values
                    # created by the reconstruction stage. Vietnamese output may
                    # keep an already valid Vietnamese target cell.
                    if target_code == 'zh-vi' and _valid_existing_target(existing):
                        continue
                    pairs.append((ws,row,dst_col,text))
                    if text not in seen: seen.add(text); sources.append(text)
        if not pairs:
            shutil.copy2(source,destination)
            return 0
        _update(callback,24,'translation',f'企业重构表已识别：{len(sources)} 条待补充术语，正在填充独立{target_label}列')
        mapping={}; pending=[]
        for src in sources:
            fixed=_glossary_vi(src) if target_code=='zh-vi' else _glossary_en(src)
            if fixed and not _CJK_RE.search(fixed):
                mapping[src]=fixed
            else:
                pending.append(src)

        # Reconstructed workbooks already have a dedicated target-language
        # column.  A bilingual client (zh-vi / zh-en) must therefore be reduced
        # to a target-only client; otherwise providers may echo the Chinese
        # source beside the translation and the quality gate incorrectly treats
        # the result as untranslated.
        working_client = client
        final_code = 'vi' if target_code == 'zh-vi' else 'en'
        if pending and isinstance(client, TranslationClient):
            working_client = _target_only_translation_client(client, final_code)

        def accept_translations(items, values):
            unresolved=[]
            for src,dst in zip(items,values):
                value=_clean_translation_candidate(src,str(dst or ''))
                if target_code == 'zh-en' and value:
                    value=_polish_automation_en(src, value)
                if value and not _CJK_RE.search(value) and value.strip() != src.strip():
                    mapping[src]=value
                else:
                    unresolved.append(src)
            return unresolved

        unresolved=list(pending)
        if unresolved:
            translated=working_client.translate_many(unresolved)
            unresolved=accept_translations(unresolved, translated)

        # Providers occasionally return the source text unchanged for a few
        # items in a large batch. Retry only those items in small batches, then
        # one-by-one. This avoids rejecting an otherwise valid workbook because
        # of transient model omissions.
        if unresolved:
            # A previous version could persist untranslated Chinese source text
            # in the target-only translation memory. Clear those poisoned rows
            # before retrying, otherwise every retry simply returns the same
            # invalid cached value and the workbook fails quality inspection.
            invalidate = getattr(working_client, 'invalidate', None)
            if callable(invalidate):
                invalidate(unresolved)
            retry_sources=list(unresolved)
            unresolved=[]
            for start in range(0,len(retry_sources),12):
                batch=retry_sources[start:start+12]
                values=working_client.translate_many(batch)
                unresolved.extend(accept_translations(batch,values))
        if unresolved:
            invalidate = getattr(working_client, 'invalidate', None)
            if callable(invalidate):
                invalidate(unresolved)
            retry_sources=list(unresolved)
            unresolved=[]
            for src in retry_sources:
                values=working_client.translate_many([src])
                unresolved.extend(accept_translations([src],values))

        # Final deterministic repair for short PLC/HMI labels. AI providers can
        # occasionally echo a small number of Chinese labels even after direct
        # retries. Structured automation labels are safely composed from the
        # embedded engineering terminology so transient API omissions no longer
        # block the complete workbook.
        still_unresolved=[]
        for src in unresolved:
            repaired=_automation_vi_fallback(src) if target_code == 'zh-vi' else _automation_en_fallback(src)
            if repaired:
                mapping[src]=repaired
            else:
                still_unresolved.append(src)
        unresolved=still_unresolved

        # Quality inspection and cleanup must use the same definition of useful
        # content. Placeholders such as 备用 / 预留 are discarded rather than
        # counted as missing translations.
        failures=[src for src in unresolved if not _is_meaningless_reconstructed_value(src)]
        if failures:
            # V31.1 delivery rule: customer files must never contain review or
            # pending-translation markers. Run the deterministic industrial
            # fallback one final time after normalizing punctuation. If a phrase
            # still cannot be converted, fail quality inspection rather than
            # silently writing a non-translation into the deliverable.
            final_failures=[]
            for src in failures:
                normalized=re.sub(r'[，。；：、]+', ' ', src).strip()
                repaired=_automation_vi_fallback(normalized) if target_code == 'zh-vi' else _automation_en_fallback(normalized)
                if repaired and not _CJK_RE.search(repaired):
                    mapping[src]=repaired
                else:
                    final_failures.append(src)
            if final_failures:
                sample='；'.join(final_failures[:20])
                # V34.4 delivery rule: unresolved terminology is a review warning,
                # not a structural processing failure. Preserve the source text in
                # the generated workbook so the customer can download and review it.
                # Only corrupted/unopenable output files are allowed to fail delivery.
                for src in final_failures:
                    mapping[src] = src
                LOGGER.warning(
                    'Quality review recommended: file=%s unresolved=%s sample=%s',
                    source.name, len(final_failures), sample,
                )
                _update(
                    callback, 72, 'quality_review',
                    f'文件可交付，建议复核 {len(final_failures)} 条未确认内容。示例：{sample}'
                )
            else:
                _update(callback,72,'translation','自动化行业二次补翻完成：交付文件无待确认标记')
        _localize_reconstructed_headers(wb, target_code)
        for ws,row,col,text in pairs:
            cell=ws.cell(row,col); cell.value=mapping[text]
            cell.font=Font(name='Arial',size=10.5)
            cell.alignment=Alignment(vertical='center',wrap_text=True)
            ws.row_dimensions[row].height=max(ws.row_dimensions[row].height or 26,30)
        destination.parent.mkdir(parents=True,exist_ok=True)
        wb.save(destination)
        _validate_xlsx_delivery_guard(destination)
        _update(callback,78,'translation',f'企业重构翻译完成：{len(pairs)} 个单元格已写入独立{target_label}列')
        return len(pairs)
    finally:
        wb.close()


def _detect_excel_translation_mode(values: list[str]) -> tuple[str, dict[str, int]]:
    """Detect whether an Excel workbook needs full translation or QA-only repair.

    The decision is intentionally automatic: customers upload a document once,
    and the engine preserves confirmed bilingual translations while repairing
    only pending or untranslated cells.
    """
    bilingual = 0
    confirmed = 0
    pending = 0
    source_only = 0
    for raw in values:
        text = str(raw or "").strip()
        if not text:
            continue
        pair = _split_existing_bilingual_text(text)
        if pair:
            bilingual += 1
            if _valid_existing_target(pair[1]):
                confirmed += 1
            else:
                pending += 1
        elif _CJK_RE.search(text):
            source_only += 1
    # A workbook with meaningful confirmed bilingual content is treated as an
    # already translated file. Mixed workbooks remain in repair mode so valid
    # customer-approved translations are never retranslated.
    mode = "repair" if confirmed >= 3 or (bilingual and confirmed >= pending) else "full"
    return mode, {
        "bilingual": bilingual,
        "confirmed": confirmed,
        "pending": pending,
        "source_only": source_only,
    }


def _publish_xlsx_package(
    source: Path,
    destination: Path,
    archive: zipfile.ZipFile,
    xml_payloads: dict[str, Any],
) -> None:
    """Write and validate an XLSX package before publishing it.

    Never truncate an existing destination while the source archive is open. A
    unique sibling temporary file is written first, validated, and then
    published. If Windows has the old destination locked, the old file is
    renamed out of the way or a unique output name is used rather than waiting
    for minutes.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)
    token = f"{os.getpid()}_{get_ident()}_{time.time_ns()}"
    staging = destination.with_name(f".{destination.stem}.{token}.staging{destination.suffix}")
    _unlink_with_retry(staging, attempts=2)
    source_names = [info.filename for info in archive.infolist()]
    try:
        with zipfile.ZipFile(staging, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as output:
            for info in archive.infolist():
                root = xml_payloads.get(info.filename + ":root")
                if isinstance(root, ET.Element):
                    data = ET.tostring(root, encoding="utf-8", xml_declaration=True)
                else:
                    data = archive.read(info.filename)
                # Repair legacy malformed PLC/HMI printf placeholders during the
                # same package write. This keeps the package single-pass and
                # removes the old second full ZIP rewrite that caused locks and
                # sharedStrings.xml loss on Windows.
                if info.filename.endswith(".xml") and b"%" in data:
                    xml_text = data.decode("utf-8", errors="strict")
                    fixed_text = _canonicalize_technical_placeholders(xml_text)
                    if fixed_text != xml_text:
                        data = fixed_text.encode("utf-8")
                output.writestr(info, data)

        with zipfile.ZipFile(staging, "r") as check:
            staged_names = set(check.namelist())
            missing = set(source_names) - staged_names
            if missing:
                raise RuntimeError(f"Excel 输出包缺少文件：{sorted(missing)[:5]}")
            broken = check.testzip()
            if broken is not None:
                raise RuntimeError(f"Excel 输出包完整性校验失败：{broken}")

        # Source and destination can become identical after cleanup/retry flows.
        # The source archive is still open here, therefore publish only to a
        # different path. The caller closes the source immediately afterwards.
        if source.resolve() == destination.resolve():
            raise RuntimeError("Excel 输出路径与源文件相同，已阻止覆盖源文件")

        try:
            os.replace(staging, destination)
        except OSError as exc:
            # Fail quickly and clearly instead of waiting for several minutes or
            # silently validating an older locked output file.
            raise RuntimeError(
                f"输出文件被系统占用，请关闭 Excel/资源管理器预览后重新处理：{destination.name}"
            ) from exc
    finally:
        _unlink_with_retry(staging, attempts=2)


def _translate_xlsx(source: Path, destination: Path, client: TranslationClient, callback: ProgressCallback | None, options: dict[str, Any] | None = None) -> int:
    """Translate XLSX text in-place inside the OOXML package."""
    perf = _PerfTrace(source.name, callback)
    options = options or {}
    requested_layout = options.get("bilingual_layout") or getattr(client, "bilingual_layout", "auto")
    bilingual_layout = _resolve_bilingual_layout(requested_layout, "xlsx")
    # Auto/vertical spreadsheet output must keep source and target in separate
    # cells. This prevents glued Chinese-Vietnamese text, duplicated PLC codes
    # and visual overflow into the next source column. Explicit inline remains
    # available only when the caller deliberately requests it.
    if str(requested_layout or "auto").strip().lower().replace("_", "-") in {"auto", "vertical", "columns", "side-by-side"}:
        bilingual_layout = "columns"
    reconstructed = _translate_reconstructed_xlsx(source, destination, client, callback)
    if reconstructed is not None:
        repaired_parts = _repair_xlsx_placeholder_corruption(destination)
        _validate_xlsx_delivery_guard(destination)
        if repaired_parts:
            _update(callback, 79, "quality_repair", f"已自动修复 {repaired_parts} 个包含损坏 PLC/HMI 占位符的文件部件")
        return reconstructed
    _update(callback, 10, "translation", "正在读取 Excel 文本索引（不会重排工作表）")
    with zipfile.ZipFile(source, "r") as archive:
        names = set(archive.namelist())
        xml_payloads: dict[str, bytes] = {}
        text_nodes: list[tuple[str, ET.Element, list[ET.Element], str]] = []
        unique_texts: list[str] = []
        seen: set[str] = set()
        ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"

        def register(package_name: str, root: ET.Element) -> None:
            for parent in root.iter():
                if parent.tag not in {ns + "si", ns + "is"}:
                    continue
                nodes = list(parent.iter(ns + "t"))
                if not nodes:
                    continue
                original = "".join(node.text or "" for node in nodes)
                normalized = _canonicalize_technical_placeholders(original)
                if not (_should_translate_excel_text(normalized) or _split_existing_bilingual_text(normalized)):
                    # Even a non-translated cell must be rewritten when an old
                    # run damaged a protected placeholder.
                    if normalized != original:
                        text_nodes.append((package_name, parent, nodes, normalized))
                        if normalized not in seen:
                            seen.add(normalized)
                            unique_texts.append(normalized)
                    continue
                text_nodes.append((package_name, parent, nodes, normalized))
                if normalized not in seen:
                    seen.add(normalized)
                    unique_texts.append(normalized)

        if "xl/sharedStrings.xml" in names:
            data = archive.read("xl/sharedStrings.xml")
            root = ET.fromstring(data)
            xml_payloads["xl/sharedStrings.xml"] = data
            register("xl/sharedStrings.xml", root)
            xml_payloads["xl/sharedStrings.xml:root"] = root  # type: ignore[assignment]

        for name in sorted(n for n in names if n.startswith("xl/worksheets/") and n.endswith(".xml")):
            data = archive.read(name)
            if b"inlineStr" not in data:
                continue
            root = ET.fromstring(data)
            xml_payloads[name] = data
            register(name, root)
            xml_payloads[name + ":root"] = root  # type: ignore[assignment]

        total = len(unique_texts)
        perf.mark("scan_ooxml")
        if not total:
            shutil.copy2(source, destination)
            _update(callback, 80, "translation", "Excel 中没有需要翻译的中文自然语言文本，已原样交付")
            return 0

        mode, mode_stats = _detect_excel_translation_mode(unique_texts)
        if mode == "repair":
            _update(
                callback,
                22,
                "translation_mode",
                f"AI 已识别为已翻译文件：自动进入智能修复模式；保留 {mode_stats['confirmed']} 条已确认译文，仅处理漏翻和待确认内容",
            )
        else:
            _update(
                callback,
                22,
                "translation_mode",
                f"AI 已识别为原始文件：自动进入完整翻译模式；待处理中文文本 {mode_stats['source_only']} 条",
            )
        _update(callback, 24, "translation", f"已建立稳定文本映射：{total} 条唯一文本；正在查询翻译记忆库")
        bilingual_target = getattr(client, "target_language_code", "") in {"zh-vi", "zh-en"}
        final_code = "vi" if getattr(client, "target_language_code", "") == "zh-vi" else "en"
        mapping: dict[str, str] = {}
        column_targets: dict[str, str] = {}
        pending_sources: list[str] = []
        translation_inputs: list[str] = []

        if bilingual_target:
            for src in unique_texts:
                existing = _split_existing_bilingual_text(src)
                if existing and _valid_existing_target(existing[1]):
                    if bilingual_layout == "columns":
                        mapping[src] = src
                        column_targets[src] = _normalize_bilingual_value(existing[0], existing[1], "target-only", options)
                    else:
                        mapping[src] = _normalize_bilingual_value(existing[0], existing[1], bilingual_layout, options)
                    continue
                # Translation QA mode: an existing bilingual cell whose target
                # is a review/pending marker is treated as unresolved. Only the
                # Chinese/source side is translated; confirmed translations are
                # preserved byte-for-byte.
                unit = _extract_chinese_translation_unit(existing[0] if existing else src)
                if not unit:
                    continue
                pending_sources.append(src)
                translation_inputs.append(unit)
            if translation_inputs:
                working_client = TranslationClient(
                    source_language=getattr(client, "source_language_code", "auto"),
                    target_language=final_code,
                )

                unresolved = list(range(len(translation_inputs)))
                accepted: dict[int, str] = {}

                # V37.2 P0 fast path: resolve high-confidence PLC/HMI labels
                # before any provider request.  This both improves terminology
                # consistency and removes hundreds of short repeated labels from
                # the network payload.
                if final_code == "vi":
                    from app.engines.translation_engine import _deterministic_plc_translation_zh_vi
                    for index, unit in enumerate(translation_inputs):
                        # V38 P0 fast path: run both the strict PLC object engine and
                        # the broader automation/HMI fallback BEFORE any provider
                        # request.  V37.2 only ran the strict engine here and deferred
                        # the fallback until after AI, so thousands of labels that the
                        # local engine could already translate were still sent across
                        # the network.
                        local_value = _deterministic_plc_translation_zh_vi(unit)
                        if not local_value:
                            local_value = _automation_vi_fallback(unit)
                        if local_value and not _CJK_RE.search(local_value):
                            accepted[index] = _normalize_vietnamese_label(local_value)
                    unresolved = [index for index in unresolved if index not in accepted]

                def accept_batch(indices: list[int], values: list[str]) -> list[int]:
                    failed: list[int] = []
                    for index, dst in zip(indices, values):
                        src = pending_sources[index]
                        unit = translation_inputs[index]
                        target_value = _clean_translation_candidate(src, str(dst or ""))
                        if final_code == 'en' and target_value:
                            target_value = _polish_automation_en(unit, target_value)
                        elif final_code == 'vi' and target_value:
                            target_value = _normalize_vietnamese_label(target_value)
                        if target_value and not _CJK_RE.search(target_value) and target_value.strip() != unit.strip():
                            accepted[index] = target_value
                        else:
                            failed.append(index)
                    return failed

                provider_count = len(unresolved)
                deterministic_count = len(accepted)
                total_pending = len(translation_inputs)
                if total_pending:
                    _update(
                        callback, 38, "quality_repair",
                        f"企业质量守护：共 {total_pending} 项；本地规则命中 {deterministic_count} 项；AI 待处理 {provider_count} 项",
                    )
                if unresolved:
                    values = working_client.translate_many([translation_inputs[i] for i in unresolved])
                    unresolved = accept_batch(unresolved, values)
                    stats = getattr(working_client, "last_batch_stats", {}) or {}
                    _update(
                        callback, 50, "quality_repair",
                        "AI 批量翻译完成："
                        f"输入 {stats.get('input_items', provider_count)} 项；"
                        f"记忆命中 {stats.get('memory_hits', 0)} 项；"
                        f"术语命中 {stats.get('rule_hits', 0)} 项；"
                        f"实际 AI {stats.get('ai_items', provider_count)} 项；"
                        f"耗时 {stats.get('elapsed_seconds', 0)}s；"
                        f"失败批次 {stats.get('failed_batches', 0)}；"
                        f"超时批次 {stats.get('timed_out_batches', 0)}；"
                        f"剩余 {len(unresolved)} 项",
                    )
                else:
                    _update(callback, 50, "quality_repair", "全部内容已由本地规则或记忆库完成，未调用 AI")
                perf.mark("translation_memory_and_ai")

                # V34.1 performance rule: first apply deterministic PLC/HMI repair,
                # then perform at most one optional network retry for the remaining
                # rows. Repeating three full provider rounds caused large batches to
                # spend most of their time in quality_repair.
                for index in list(unresolved):
                    unit = translation_inputs[index]
                    repaired = _automation_vi_fallback(unit) if final_code == 'vi' else _automation_en_fallback(unit)
                    if repaired and not _CJK_RE.search(repaired):
                        accepted[index] = repaired
                        unresolved.remove(index)

                max_network_repair_rounds = max(0, min(1, int(os.getenv("QUALITY_REPAIR_NETWORK_ROUNDS", "0"))))
                for repair_round in range(max_network_repair_rounds):
                    if not unresolved:
                        break
                    invalidate = getattr(working_client, "invalidate", None)
                    if callable(invalidate):
                        invalidate([translation_inputs[i] for i in unresolved])
                    before_count = len(unresolved)
                    retry = list(unresolved)
                    values = working_client.translate_many([translation_inputs[i] for i in retry])
                    unresolved = accept_batch(retry, values)
                    _update(callback, 64, "quality_repair", f"增量修复：{before_count} → {len(unresolved)}")

                # Deterministic automation fallback guarantees that common PLC/HMI
                # labels such as 备用、气缸IO输入_原点、正转/反转 are not silently left
                # in Chinese when the provider echoes the source.
                for index in list(unresolved):
                    unit = translation_inputs[index]
                    repaired = _automation_vi_fallback(unit) if final_code == 'vi' else _automation_en_fallback(unit)
                    if repaired and not _CJK_RE.search(repaired):
                        accepted[index] = repaired
                        unresolved.remove(index)

                for index, src in enumerate(pending_sources):
                    if index in accepted:
                        if bilingual_layout == "columns":
                            mapping[src] = src
                            column_targets[src] = _normalize_bilingual_value(src, accepted[index], "target-only", options)
                        else:
                            mapping[src] = _normalize_bilingual_value(src, accepted[index], bilingual_layout, options)

                if unresolved:
                    samples = '；'.join(pending_sources[i] for i in unresolved[:20])
                    # V34.4 quality grading: remaining untranslated/review items do
                    # not invalidate an otherwise readable workbook. Keep those cells
                    # unchanged, deliver the file, and surface a clear review warning.
                    LOGGER.warning(
                        'Quality review recommended: file=%s unresolved=%s sample=%s',
                        source.name, len(unresolved), samples,
                    )
                    _update(
                        callback, 73, "quality_review",
                        f"自动修复完成：{total_pending} → {len(unresolved)}；文件可交付，建议人工复核剩余内容"
                    )
                elif total_pending:
                    _update(callback, 73, "quality_repair", f"企业质量守护修复完成：{total_pending} → 0，验收通过")
        else:
            translated = client.translate_many(unique_texts)
            for src, dst in zip(unique_texts, translated):
                value = str(dst or "").strip()
                if value:
                    mapping[src] = value
        changed = 0
        changed_values: list[str] = []
        for _, _, nodes, original in text_nodes:
            value = mapping.get(original, original)
            if value == original:
                continue
            nodes[0].text = value
            nodes[0].set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            for node in nodes[1:]:
                node.text = ""
            changed += 1
            changed_values.append(value)

        _update(callback, 76, "translation", f"翻译完成：{changed} 个文本项；正在写入交付文件并校验包结构")
        # V35 write-back engine: write a newly generated order output directly
        # to its final unique path.  The previous temp-file + os.replace flow
        # could block for several minutes on Windows antivirus/preview hooks,
        # even though XML translation itself finished in under one second.
        # Order outputs are unique and unpublished at this point, so an atomic
        # replacement provides no customer-visible benefit here.
        step_started = time.perf_counter()
        _debug_step(source.name, "publish_xlsx_package", "ENTER", step_started)
        _publish_xlsx_package(source, destination, archive, xml_payloads)
        _debug_step(source.name, "publish_xlsx_package", "FINISHED", step_started)
        perf.mark("write_ooxml")

    _debug_step(source.name, "post_write_pipeline", "ENTER")
    if bilingual_layout == "columns" and column_targets:
        step_started = time.perf_counter()
        _debug_step(source.name, "side_by_side_layout", "ENTER", step_started, items=len(column_targets))
        created_columns = _apply_excel_side_by_side_layout(destination, column_targets, options)
        _debug_step(source.name, "side_by_side_layout", "FINISHED", step_started, changed=created_columns)
        _update(callback, 77, "translation", f"已生成真正左右分列：{created_columns} 个中外文对应单元格")
    else:
        _debug_step(source.name, "side_by_side_layout", "SKIPPED", items=len(column_targets), layout=bilingual_layout)
    _update(callback, 77, "quality_repair", "正在执行轻量级占位符与版式检查")
    # Placeholder normalization has already been applied to every translated
    # shared/inline string in the primary OOXML pass. Do not rebuild the whole
    # package a second time; that historical second rewrite caused Windows file
    # locks, multi-minute stalls and missing sharedStrings.xml failures.
    repaired_parts = 0
    LOGGER.info("PERF file=%s stage=placeholder_repair elapsed=0.000s changed=0 skipped=True", destination.name)
    layout_started = time.perf_counter()
    # Only vertical bilingual output creates generated line breaks.  Inline,
    # columns and target-only modes must not rescan/rebuild the whole XLSX merely
    # because legacy source strings contain dash-like separators.
    step_started = time.perf_counter()
    _debug_step(source.name, "multiline_layout", "ENTER", step_started, changed_values=len(changed_values), layout=bilingual_layout)
    needs_multiline_layout = _needs_multiline_layout(bilingual_layout, changed_values)
    if needs_multiline_layout:
        _apply_excel_multiline_layout(destination)
    _debug_step(source.name, "multiline_layout", "FINISHED", step_started, applied=needs_multiline_layout)
    LOGGER.info(
        "PERF file=%s stage=multiline_layout elapsed=%.3fs skipped=%s",
        destination.name,
        time.perf_counter()-layout_started,
        not needs_multiline_layout,
    )
    perf.mark("layout_and_placeholder_repair")
    step_started = time.perf_counter()
    _debug_step(source.name, "delivery_validation", "ENTER", step_started)
    _validate_xlsx_delivery_guard(destination)
    _debug_step(source.name, "delivery_validation", "FINISHED", step_started)
    perf.mark("delivery_validation")
    _debug_step(source.name, "translate_xlsx", "FINISHED", changed=changed)
    _update(callback, 80, "translation", f"Excel 原位翻译完成；PLC 编号已保护，双语排版为 {bilingual_layout}；缓存命中 {getattr(client, 'persistent_cache_hits', 0)}；约剩余 0 秒；性能：{perf.summary()}")
    return changed


def _should_translate_excel_text(text: str) -> bool:
    value = str(text or "").strip()
    if not value or value.startswith("="):
        return False
    if value.startswith(("http://", "https://", "mailto:")):
        return False
    if value.upper() in {"#N/A", "#VALUE!", "#REF!", "#DIV/0!", "#NAME?", "#NUM!", "#NULL!"}:
        return False
    if re.fullmatch(r"[\d\s.,:;/%+\-_=()\[\]{}<>#@|\\]+", value):
        return False
    if re.fullmatch(r"(?:[A-Za-z]{1,8}\d+[A-Za-z0-9_.:/\-]*|[A-Za-z0-9]+(?:_[A-Za-z0-9]+)+|[A-Z]{2,}[A-Z0-9_.:/\-]*)", value):
        return False
    has_cjk = bool(_CJK_RE.search(value))
    has_latin_language = bool(re.search(r"[A-Za-zÀ-ỹ]{3,}", value))
    return has_cjk or has_latin_language


def _translate_pdf_to_docx(source: Path, destination: Path, client: TranslationClient, callback: ProgressCallback | None) -> int:
    reader = PdfReader(source)
    document = Document()
    total = max(1, len(reader.pages))
    translated = 0
    for index, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        if text.strip():
            document.add_heading(f"Page {index}", level=2)
            for block in [part.strip() for part in text.split("\n\n") if part.strip()]:
                document.add_paragraph(client.translate(block))
                translated += 1
        _update(callback, 35 + int(index / total * 45), "translation", f"Translated PDF page {index}/{total}")
    document.save(destination)
    return translated




IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}

def _translated_ocr_text(text: str, client: TranslationClient | None) -> str:
    if not text.strip() or client is None:
        return text
    # Translate line-by-line to retain invoice/list structure and reduce provider failures.
    output: list[str] = []
    for line in text.splitlines():
        if not line.strip():
            output.append("")
            continue
        translated = client.translate(line)
        output.append(str(translated or line).strip())
    return "\n".join(output).strip()

def _add_ocr_text(document: Document, text: str, target_code: str = "") -> int:
    count = 0
    for line in text.splitlines():
        if not line.strip():
            continue
        paragraph = document.add_paragraph()
        run = paragraph.add_run(line.strip())
        _apply_target_font(run, target_code)
        count += 1
    return count


def _detect_ocr_language(text: str) -> str:
    value = text or ""
    cjk = sum(1 for ch in value if "\u4e00" <= ch <= "\u9fff")
    vietnamese_marks = sum(1 for ch in value.lower() if ch in "ăâđêôơưáàảãạấầẩẫậắằẳẵặéèẻẽẹếềểễệíìỉĩịóòỏõọốồổỗộớờởỡợúùủũụứừửữựýỳỷỹỵ")
    latin = sum(1 for ch in value if ch.isascii() and ch.isalpha())
    if cjk and latin:
        return "中英混合"
    if cjk:
        return "中文"
    if vietnamese_marks:
        return "越南语"
    if latin:
        return "英文"
    return "未知"


def _looks_like_invoice(text: str) -> bool:
    upper = (text or "").upper()
    signals = ("INVOICE", "发票", "TOTAL", "总计", "UNIT PRICE", "单价", "AMOUNT", "金额")
    return sum(1 for token in signals if token in upper or token in text) >= 3


def _invoice_fields(lines: list[str]) -> tuple[list[str], list[list[str]], list[str]]:
    """Extract a practical invoice header, line-item table, and footer.

    This is intentionally conservative: it preserves every unparsed line in the
    header/footer rather than silently dropping OCR content.
    """
    clean = [" ".join(line.split()) for line in lines if line.strip()]
    header: list[str] = []
    rows: list[list[str]] = []
    footer: list[str] = []
    table_started = False
    for line in clean:
        normalized = line.replace("，", ",")
        if any(key in normalized.lower() for key in ("description", "unit price", "amount")) or all(key in normalized for key in ("数量", "金额")):
            table_started = True
            continue
        if any(key in normalized.lower() for key in ("total:", "payment:")) or normalized.startswith(("总计", "付款")):
            footer.append(normalized)
            table_started = False
            continue
        if table_started:
            # Typical invoice row: description + qty + unit price + amount.
            match = re.match(r"^(.*?)\s+(\d+)\s+([\d,.]+)\s+([\d,.]+(?:\s*[A-Za-z]{3})?)$", normalized)
            if match:
                rows.append([match.group(1).strip(), match.group(2), match.group(3), match.group(4)])
                continue
        if rows:
            footer.append(normalized)
        else:
            header.append(normalized)
    return header, rows, footer


def _set_cell_text(cell, value: str, target_code: str, bold: bool = False) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    run = paragraph.add_run(value)
    run.bold = bold
    _apply_target_font(run, target_code)


def _build_editable_ocr_document(source: Path, translated: str, ocr_text: str, client: TranslationClient | None) -> tuple[Document, int, str]:
    """Build an editable, single-flow Word document from OCR results.

    V14 placed a generic title, the source image, and recognized text on three
    separate pages. V15 instead puts the editable result first and uses document-
    specific structures such as invoice tables. The original scan is appended as
    evidence without forcing an empty cover page.
    """
    document = Document()
    target_code = getattr(client, "target_language_code", "") if client else ""
    _configure_document_fonts(document, target_code)
    for section in document.sections:
        section.top_margin = Cm(1.7)
        section.bottom_margin = Cm(1.7)
        section.left_margin = Cm(1.8)
        section.right_margin = Cm(1.8)

    lines = [line for line in translated.splitlines() if line.strip()]
    blocks = 0
    template = "generic"
    if _looks_like_invoice(translated):
        template = "invoice"
        header, rows, footer = _invoice_fields(lines)
        title = next((line for line in header if "发票" in line or "INVOICE" in line.upper()), "发票识别结果")
        heading = document.add_heading(title, level=1)
        heading.alignment = 1
        blocks += 1
        for line in header:
            if line == title:
                continue
            p = document.add_paragraph()
            run = p.add_run(line)
            _apply_target_font(run, target_code)
            blocks += 1
        if rows:
            table = document.add_table(rows=1, cols=4)
            table.style = "Table Grid"
            headers = ["描述", "数量", "单价", "金额"] if target_code.startswith("zh") else ["Description", "Qty", "Unit Price", "Amount"]
            for idx, value in enumerate(headers):
                _set_cell_text(table.rows[0].cells[idx], value, target_code, bold=True)
            for row in rows:
                cells = table.add_row().cells
                for idx, value in enumerate(row):
                    _set_cell_text(cells[idx], value, target_code)
            blocks += len(rows) + 1
        for line in footer:
            p = document.add_paragraph()
            run = p.add_run(line)
            run.bold = line.startswith(("总计", "Total"))
            _apply_target_font(run, target_code)
            blocks += 1
    else:
        title = lines[0] if lines else ("OCR 识别结果" if target_code.startswith("zh") else "OCR Result")
        document.add_heading(title, level=1)
        blocks += 1
        for line in lines[1:]:
            p = document.add_paragraph()
            run = p.add_run(line)
            _apply_target_font(run, target_code)
            blocks += 1

    # Keep the scan as an appendix/evidence, not as the first user-visible page.
    if os.getenv("OCR_INCLUDE_SOURCE_IMAGE", "1").strip().lower() not in {"0", "false", "no"}:
        document.add_paragraph()
        label = "原始扫描件" if target_code.startswith("zh") else "Original scan"
        run = document.add_paragraph().add_run(label)
        run.bold = True
        _apply_target_font(run, target_code)
        try:
            document.add_picture(str(source), width=Inches(5.8))
        except Exception:
            pass

    document.core_properties.title = lines[0] if lines else source.stem
    document.core_properties.comments = "Editable OCR reconstruction by Document Automation AI V15"
    return document, blocks, template


def _image_to_docx(source: Path, destination: Path, client: TranslationClient | None, callback: ProgressCallback | None) -> dict[str, Any]:
    _update(callback, 38, "ocr", f"Reading image: {source.name}")
    preferred = getattr(client, "source_language_code", "auto") if client else "auto"
    ocr_text = extract_text_from_image(source, preferred)
    if not ocr_text.strip():
        raise RuntimeError(f"OCR produced no readable text for {source.name}.")
    _update(callback, 58, "ocr", f"OCR extracted {len(ocr_text)} characters")
    translated = _translated_ocr_text(ocr_text, client)
    document, blocks, template = _build_editable_ocr_document(source, translated, ocr_text, client)
    document.save(destination)
    validation = _validate_docx(destination)
    if validation["text_blocks"] == 0 or validation["characters"] == 0:
        raise RuntimeError("Generated OCR DOCX is empty; delivery was blocked.")
    return {
        "translated_items": blocks if client else 0,
        "ocr_characters": len(ocr_text),
        "ocr_text_blocks": len([x for x in ocr_text.splitlines() if x.strip()]),
        "recognized_language": _detect_ocr_language(ocr_text),
        "output_template": template,
        "editable_output": True,
        "validation": validation,
        "mode": "ocr_layout_reconstruction" if client else "ocr_layout",
    }

def _scanned_pdf_to_docx(source: Path, destination: Path, client: TranslationClient | None, callback: ProgressCallback | None) -> dict[str, Any]:
    if fitz is None:
        raise RuntimeError("PyMuPDF is required for scanned PDF OCR.")
    pdf = fitz.open(source)
    document = Document()
    target_code = getattr(client, "target_language_code", "") if client else ""
    _configure_document_fonts(document, target_code)
    total_chars = 0
    total_blocks = 0
    import tempfile
    with tempfile.TemporaryDirectory(prefix="docai_ocr_") as temp_dir:
        for index, page in enumerate(pdf, start=1):
            pix = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False)
            page_image = Path(temp_dir) / f"page_{index}.png"
            pix.save(str(page_image))
            preferred = getattr(client, "source_language_code", "auto") if client else "auto"
            ocr_text = extract_text_from_image(page_image, preferred)
            if not ocr_text.strip():
                continue
            translated = _translated_ocr_text(ocr_text, client)
            if index > 1:
                document.add_page_break()
            document.add_heading(f"Page {index}", level=1)
            total_blocks += _add_ocr_text(document, translated, target_code)
            if os.getenv("OCR_INCLUDE_SOURCE_IMAGE", "1").strip().lower() not in {"0", "false", "no"}:
                label = "原始扫描页" if target_code.startswith("zh") else "Original scanned page"
                run = document.add_paragraph().add_run(label)
                run.bold = True
                _apply_target_font(run, target_code)
                try:
                    document.add_picture(str(page_image), width=Inches(5.8))
                except Exception:
                    pass
            total_chars += len(ocr_text)
            _update(callback, 35 + int(index / max(1, len(pdf)) * 45), "ocr", f"OCR PDF page {index}/{len(pdf)}")
    pdf.close()
    if total_chars == 0:
        raise RuntimeError(f"OCR produced no readable text for scanned PDF {source.name}.")
    document.core_properties.comments = "Scanned PDF OCR and editable reconstruction by Document Automation AI V15"
    document.save(destination)
    validation = _validate_docx(destination)
    if validation["characters"] == 0:
        raise RuntimeError("Generated scanned-PDF DOCX is empty; delivery was blocked.")
    return {"translated_items": total_blocks if client else 0, "ocr_characters": total_chars, "ocr_text_blocks": total_blocks, "validation": validation, "mode": "scanned_pdf_ocr"}



def _normalize_text_value(value: str) -> str:
    value = value.replace("\u00a0", " ").replace("\u3000", " ")
    value = re.sub(r"[ \t]+", " ", value)
    return value.strip()


def _column_number(cell_ref: str) -> int:
    letters = re.match(r"[A-Za-z]+", cell_ref or "")
    if not letters:
        return 0
    value = 0
    for char in letters.group(0).upper():
        value = value * 26 + (ord(char) - 64)
    return value


def _cell_position(cell_ref: str) -> tuple[int, int]:
    match = re.fullmatch(r"([A-Za-z]+)(\d+)", cell_ref or "")
    if not match:
        return 0, 0
    return int(match.group(2)), _column_number(match.group(1))


def _compact_worksheet_xml(raw: bytes) -> tuple[bytes, dict[str, int]]:
    """Trim pathological trailing empty formatting cells without moving data.

    This implementation is deliberately row-oriented. A customer workbook may
    contain more than 18 million self-closing empty ``<c .../>`` elements; a
    cell-by-cell Python callback would be unacceptably slow. Meaningful cells are
    located from their closing tags, then each row is cut once at the first
    column beyond the protected data region.
    """
    ref_re = re.compile(rb'\br="([A-Za-z]+\d+)"')
    meaningful: list[tuple[int, int]] = []
    search_from = 0
    meaningful_cells = 0
    while True:
        close_at = raw.find(b"</c>", search_from)
        if close_at < 0:
            break
        open_at = raw.rfind(b"<c", 0, close_at)
        header_end = raw.find(b">", open_at, close_at) if open_at >= 0 else -1
        if open_at >= 0 and header_end >= 0:
            ref_match = ref_re.search(raw[open_at:header_end + 1])
            if ref_match:
                meaningful.append(_cell_position(ref_match.group(1).decode("ascii", "ignore")))
                meaningful_cells += 1
        search_from = close_at + 4

    for merge_ref in re.findall(rb'<mergeCell\s+ref="([A-Za-z]+\d+):([A-Za-z]+\d+)"', raw):
        for ref in merge_ref:
            meaningful.append(_cell_position(ref.decode("ascii", "ignore")))

    if not meaningful:
        return raw, {"cells_seen": 0, "phantom_cells_removed": 0, "rows_removed": 0}

    max_row = max(row for row, _ in meaningful)
    max_col = max(col for _, col in meaningful)
    protected_row = max_row + 10
    protected_col = max_col + 5
    cutoff_column = get_column_letter(protected_col + 1)

    output = bytearray()
    cursor = 0
    removed_cells = 0
    rows_removed = 0
    rows_seen = 0
    while True:
        row_start = raw.find(b"<row", cursor)
        if row_start < 0:
            output.extend(raw[cursor:])
            break
        row_end = raw.find(b"</row>", row_start)
        if row_end < 0:
            output.extend(raw[cursor:])
            break
        row_end += len(b"</row>")
        output.extend(raw[cursor:row_start])
        row_block = raw[row_start:row_end]
        header_end = row_block.find(b">")
        row_match = re.search(rb'\br="(\d+)"', row_block[:header_end + 1])
        row_number = int(row_match.group(1)) if row_match else 0
        rows_seen += 1

        # Rows after the real data region that contain no meaningful cell are
        # pure formatting noise and can be removed as a whole.
        if row_number > protected_row and b"</c>" not in row_block:
            removed_cells += row_block.count(b"<c ") + row_block.count(b"<c>")
            rows_removed += 1
        else:
            cutoff_ref = f'r="{cutoff_column}{row_number}"'.encode("ascii")
            cutoff_at = row_block.find(cutoff_ref)
            if cutoff_at < 0:
                # Sparse worksheets may jump directly from A to XFD. Find the
                # first referenced cell beyond the protected column.
                for ref_match in ref_re.finditer(row_block):
                    ref_text = ref_match.group(1).decode("ascii", "ignore")
                    ref_row, ref_col = _cell_position(ref_text)
                    if ref_row == row_number and ref_col > protected_col:
                        cutoff_at = ref_match.start()
                        break
            if cutoff_at >= 0:
                cell_start = row_block.rfind(b"<c", 0, cutoff_at)
                if cell_start >= 0:
                    removed_cells += row_block[cell_start:].count(b"<c ") + row_block[cell_start:].count(b"<c>")
                    row_block = row_block[:cell_start] + b"</row>"
            output.extend(row_block)
        cursor = row_end

    compacted = bytes(output)
    end_ref = f"{get_column_letter(max(1, max_col))}{max(1, max_row)}".encode("ascii")
    compacted = re.sub(rb'<dimension\s+ref="[^"]+"\s*/>', b'<dimension ref="A1:' + end_ref + b'"/>', compacted, count=1)
    return compacted, {
        "cells_seen": meaningful_cells,
        "phantom_cells_removed": removed_cells,
        "rows_removed": rows_removed,
        "rows_seen": rows_seen,
        "used_rows": max_row,
        "used_columns": max_col,
    }


def _detect_header_rows(ws, max_scan: int = 20) -> tuple[int, int]:
    """Return (title_row, header_row) using conservative visual/data heuristics."""
    nonempty_rows: list[tuple[int, int, int]] = []
    max_col = min(max(1, ws.max_column), 200)
    for r in range(1, min(ws.max_row, max_scan) + 1):
        values = [ws.cell(r, c).value for c in range(1, max_col + 1)]
        nonempty = sum(v not in (None, '') for v in values)
        text = sum(isinstance(v, str) and bool(v.strip()) for v in values)
        if nonempty:
            nonempty_rows.append((r, nonempty, text))
    if not nonempty_rows:
        return 0, 0
    title_row = nonempty_rows[0][0]
    # A title is usually sparse; a header is the first denser textual row.
    header_row = title_row
    for r, nonempty, text in nonempty_rows:
        if r > title_row and nonempty >= 2 and text >= max(1, nonempty // 2):
            header_row = r
            break
    return title_row, header_row




def _copy_cell_visual(source_cell, target_cell) -> None:
    target_cell.value = source_cell.value
    if source_cell.has_style:
        target_cell._style = copy.copy(source_cell._style)
    if source_cell.number_format:
        target_cell.number_format = source_cell.number_format
    target_cell.font = copy.copy(source_cell.font)
    target_cell.fill = copy.copy(source_cell.fill)
    target_cell.border = copy.copy(source_cell.border)
    target_cell.alignment = copy.copy(source_cell.alignment)
    target_cell.protection = copy.copy(source_cell.protection)


def _worksheet_content_bounds(ws) -> tuple[int, int]:
    """Return the last row/column containing real content.

    Worksheet.max_column can be inflated by formatting-only cells. Print layout
    must be based on actual values/formulas, merged ranges with content, and
    drawing anchors rather than the formatted tail.
    """
    max_row = 1
    max_col = 1
    for row in ws.iter_rows():
        for cell in row:
            if cell.value not in (None, ""):
                max_row = max(max_row, cell.row)
                max_col = max(max_col, cell.column)
    for merged in ws.merged_cells.ranges:
        anchor = ws.cell(merged.min_row, merged.min_col).value
        if anchor not in (None, ""):
            max_row = max(max_row, merged.max_row)
            max_col = max(max_col, merged.max_col)
    for image in getattr(ws, "_images", []):
        anchor = getattr(image, "anchor", None)
        marker = getattr(anchor, "_to", None) or getattr(anchor, "from_", None)
        if marker is not None:
            max_row = max(max_row, int(getattr(marker, "row", 0)) + 1)
            max_col = max(max_col, int(getattr(marker, "col", 0)) + 1)
    return max_row, max_col

def _is_simple_list_sheet(ws, max_row: int, max_col: int) -> bool:
    if max_row < 80 or max_col > 4 or ws.merged_cells.ranges or getattr(ws, "_images", []):
        return False
    nonempty_rows = 0
    formula_cells = 0
    dense_rows = 0
    for row in ws.iter_rows(min_row=1, max_row=max_row, max_col=max_col):
        values = [cell.value for cell in row]
        occupied = sum(value not in (None, "") for value in values)
        if occupied:
            nonempty_rows += 1
        if occupied > 4:
            dense_rows += 1
        formula_cells += sum(isinstance(value, str) and value.startswith("=") for value in values)
    return nonempty_rows >= 40 and dense_rows == 0 and formula_cells == 0

def _reflow_sparse_tail_to_right(ws, max_row: int | None = None, max_col: int | None = None) -> dict[str, int]:
    """Reflow only a genuinely simple list into two A4 columns.

    Complex PLC matrices are never moved. The previous implementation tried to
    move a sparse tail inside a wide matrix and could create unreadable sheets.
    """
    max_row, max_col = (max_row or _worksheet_content_bounds(ws)[0], max_col or _worksheet_content_bounds(ws)[1])
    if not _is_simple_list_sheet(ws, max_row, max_col):
        return {"moved_rows": 0, "start_row": 0, "mode": "preserve_complex_layout"}
    rows = []
    for r in range(1, max_row + 1):
        if any(ws.cell(r, c).value not in (None, "") for c in range(1, max_col + 1)):
            rows.append(r)
    # Preserve likely title/header rows and split only the data body.
    title_row, header_row = _detect_header_rows(ws)
    first_data = max(header_row + 1, 1)
    data_rows = [r for r in rows if r >= first_data]
    if len(data_rows) < 60:
        return {"moved_rows": 0, "start_row": first_data, "mode": "short_list"}
    split = (len(data_rows) + 1) // 2
    left_rows = data_rows[:split]
    right_rows = data_rows[split:]
    offset = max_col + 2
    for src_r, dst_r in zip(right_rows, left_rows):
        for c in range(1, max_col + 1):
            src = ws.cell(src_r, c)
            dst = ws.cell(dst_r, c + offset)
            _copy_cell_visual(src, dst)
            src.value = None
        if ws.row_dimensions[src_r].height and not ws.row_dimensions[dst_r].height:
            ws.row_dimensions[dst_r].height = ws.row_dimensions[src_r].height
    for c in range(1, max_col + 1):
        src_letter = get_column_letter(c)
        dst_letter = get_column_letter(c + offset)
        ws.column_dimensions[dst_letter].width = ws.column_dimensions[src_letter].width
    return {"moved_rows": len(right_rows), "start_row": first_data, "mode": "simple_two_column", "output_max_col": max_col * 2 + 2}

def _set_horizontal_page_breaks(ws, max_col: int, width_budget: float = 95.0) -> int:
    """Add A4-width column breaks without shrinking a wide matrix to one page."""
    ws.col_breaks = type(ws.col_breaks)()
    pages = 1
    used = 0.0
    for c in range(1, max_col + 1):
        letter = get_column_letter(c)
        width = float(ws.column_dimensions[letter].width or 8.43)
        if c > 1 and used + width > width_budget:
            ws.col_breaks.append(Break(id=c - 1))
            pages += 1
            used = 0.0
        used += width
    return pages

def _organize_xlsx_a4(source: Path, destination: Path, callback: ProgressCallback | None = None) -> dict[str, Any]:
    """Create a readable enterprise-organized workbook.

    The organizer no longer forces A4 fitting, moves rows into artificial
    columns, or shrinks a complex PLC matrix. It preserves the worksheet
    structure and improves only visible readability: real content bounds,
    practical widths, wrapped bilingual text, readable row heights, and safe
    print metadata. Empty sheets remain empty but are never created or cleared.
    """
    _update(callback, 12, 'cleanup', '正在分析工作表结构、有效区域、列宽和文字可读性')
    prepared, temporary = _prepare_xlsx_for_processing(source, callback, 'cleanup')
    try:
        wb = load_workbook(prepared, data_only=False)
    except (KeyError, ValueError, OSError):
        with zipfile.ZipFile(source, 'r') as src_zip, zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as dst_zip:
            totals = {'mode': 'safe_compaction_fallback', 'sheets': 0, 'structure_changed': False}
            for info in src_zip.infolist():
                payload = src_zip.read(info.filename)
                if info.filename.startswith('xl/worksheets/') and info.filename.endswith('.xml'):
                    payload, stats = _compact_worksheet_xml(payload)
                    totals['sheets'] += 1
                    totals['structure_changed'] = totals['structure_changed'] or bool(stats.get('phantom_cells_removed') or stats.get('rows_removed'))
                dst_zip.writestr(info, payload)
        return totals

    totals: dict[str, Any] = {
        'mode': 'readable_enterprise_layout',
        'sheets': 0,
        'content_bounds': {},
        'empty_sheets': [],
        'structure_changed': False,
    }
    try:
        for index, ws in enumerate(wb.worksheets, start=1):
            max_row, max_col = _worksheet_content_bounds(ws)
            has_content = any(
                cell.value not in (None, '')
                for row in ws.iter_rows(min_row=1, max_row=max_row, max_col=max_col)
                for cell in row
            )
            if not has_content:
                totals['empty_sheets'].append(ws.title)
                totals['content_bounds'][ws.title] = {'max_row': 0, 'max_col': 0}
                continue

            title_row, header_row = _detect_header_rows(ws)
            totals['content_bounds'][ws.title] = {'max_row': max_row, 'max_col': max_col}

            # Never move cells. Remove historical page-fit settings that made
            # hundreds of columns unreadably small.
            ws.sheet_properties.pageSetUpPr.fitToPage = False
            ws.page_setup.fitToWidth = 0
            ws.page_setup.fitToHeight = 0
            ws.page_setup.scale = 100
            ws.print_area = f'A1:{get_column_letter(max_col)}{max_row}'
            ws.row_breaks = type(ws.row_breaks)()
            ws.col_breaks = type(ws.col_breaks)()
            ws.sheet_view.showGridLines = True
            ws.sheet_view.zoomScale = 100

            # Keep existing orientation when present; otherwise use landscape
            # for matrix sheets and portrait for narrow lists.
            if not ws.page_setup.orientation:
                ws.page_setup.orientation = 'landscape' if max_col > 8 else 'portrait'
            ws.page_margins.left = 0.3
            ws.page_margins.right = 0.3
            ws.page_margins.top = 0.45
            ws.page_margins.bottom = 0.45

            # Determine widths from visible content without exploding columns.
            for c in range(1, max_col + 1):
                letter = get_column_letter(c)
                existing = ws.column_dimensions[letter].width
                samples: list[str] = []
                for r in range(1, min(max_row, 400) + 1):
                    value = ws.cell(r, c).value
                    if value not in (None, ''):
                        samples.append(str(value))
                if not samples:
                    continue
                max_line = max((max((len(x) for x in text.splitlines()), default=0) for text in samples), default=0)
                bilingual = any(('\n' in text or ' —— ' in text) for text in samples)
                desired = max(8.5, min(22.0 if bilingual else 18.0, max_line * 1.15 + 2))
                if existing is None or existing < 6 or existing > 35:
                    ws.column_dimensions[letter].width = desired
                else:
                    ws.column_dimensions[letter].width = min(24.0, max(8.0, float(existing)))

            # Normalize readability while preserving colors, borders and values.
            for r in range(1, max_row + 1):
                line_count = 1
                char_count = 0
                row_has_text = False
                for c in range(1, max_col + 1):
                    cell = ws.cell(r, c)
                    value = cell.value
                    if value in (None, ''):
                        continue
                    if isinstance(value, str):
                        row_has_text = True
                        line_count = max(line_count, value.count('\n') + 1)
                        char_count = max(char_count, max((len(x) for x in value.splitlines()), default=0))
                        cell.alignment = cell.alignment.copy(
                            wrap_text=True,
                            vertical='center',
                            horizontal=cell.alignment.horizontal or 'left',
                        )
                        current_size = cell.font.sz or 11
                        if current_size < 10.5:
                            cell.font = cell.font.copy(size=10.5)
                    elif cell.alignment.vertical is None:
                        cell.alignment = cell.alignment.copy(vertical='center')

                if row_has_text:
                    required = max(20.0, 17.0 * line_count)
                    if char_count > 28:
                        required += min(24.0, ((char_count - 1) // 28) * 6.0)
                    existing_h = ws.row_dimensions[r].height or 0
                    ws.row_dimensions[r].height = min(90.0, max(existing_h, required))

            if title_row:
                for cell in ws[title_row][:max_col]:
                    if cell.value not in (None, ''):
                        cell.font = cell.font.copy(bold=True, size=max(13, cell.font.sz or 11))
                        cell.alignment = cell.alignment.copy(wrap_text=True, vertical='center')
            if header_row:
                for cell in ws[header_row][:max_col]:
                    if cell.value not in (None, ''):
                        cell.font = cell.font.copy(bold=True, size=max(10.5, cell.font.sz or 10.5))
                        cell.alignment = cell.alignment.copy(wrap_text=True, vertical='center', horizontal='center')
                ws.freeze_panes = ws.freeze_panes or f'A{header_row + 1}'
                ws.print_title_rows = f'{header_row}:{header_row}'

            totals['sheets'] += 1
            _update(callback, 18 + int(index / max(1, len(wb.worksheets)) * 70), 'cleanup', f'整理工作表 {index}/{len(wb.worksheets)}：{ws.title}，有效区域 {max_row} 行 × {max_col} 列')

        destination.parent.mkdir(parents=True, exist_ok=True)
        wb.save(destination)
    finally:
        wb.close()
        if temporary:
            temporary.unlink(missing_ok=True)

    with zipfile.ZipFile(destination, 'r') as archive:
        bad = archive.testzip()
        if bad:
            _unlink_with_retry(destination)
            raise RuntimeError(f'智能整理输出校验失败：{bad}')
    totals['source_size_bytes'] = source.stat().st_size
    totals['output_size_bytes'] = destination.stat().st_size
    _update(callback, 92, 'cleanup', f"智能整理完成：{totals['sheets']} 个有效工作表；未移动任何单元格")
    return totals



def _classify_plc_function(name: str) -> str:
    value = str(name or '').strip()
    rules = [
        ('安全与急停', ('急停', '安全门', '安全继电器')),
        ('操作按钮', ('启动', '暂停', '停止', '复位', '旋钮', '按钮')),
        ('载具输送', ('载具', '运输板', '送料', '收料', '皮带', '小车')),
        ('检测与视觉', ('检测', '视觉', '相机', '扫码', 'AOI')),
        ('气动与真空', ('气缸', '夹爪', '真空', '顶升', '阻挡')),
        ('报警与状态', ('报警', '故障', '状态', '到位', '感应')),
    ]
    for category, words in rules:
        if any(word in value for word in words):
            return category
    if '备用' in value:
        return '备用信号'
    return '其他'


def _split_code_name(value: object) -> tuple[str, str]:
    text = str(value or '').strip()
    if not text or text.upper() in {'#N/A', '#VALUE!', '#REF!'}:
        return '', ''
    text = re.sub(r'\s+', ' ', text)
    match = re.match(r'^([A-Za-z]{1,8}\d+|NOT\d+|DOG\d+|POT\d+)\s*[|：:]?\s*(.*)$', text, re.I)
    if match:
        return match.group(1).upper(), match.group(2).strip()
    return '', text


def _clean_reconstructed_value(value: object) -> str:
    text = str(value or '').strip()
    if not text or text.upper() in {'#N/A', '#VALUE!', '#REF!', '#DIV/0!', '#NAME?'}:
        return ''
    return re.sub(r'\s+', ' ', text).strip()


def _source_only_reconstructed_value(value: object) -> str:
    """Return the Chinese/source part from legacy glued bilingual cells.

    PLC/HMI exports often contain values such as ``备用Dự phòng`` or
    ``前门关闭Cửa trước đã đóng``.  Reconstruction must classify and dedupe
    the Chinese engineering meaning, not carry the historical mixed string
    into the new customer workbook.
    """
    text = _clean_reconstructed_value(value)
    if not text:
        return ''
    pair = _split_existing_bilingual_text(text)
    if pair:
        text = pair[0]
    return re.sub(r'\s+', ' ', text).strip(' |：:—-')


def _is_meaningless_reconstructed_value(value: object) -> bool:
    text = _source_only_reconstructed_value(value)
    if not text:
        return True
    compact = re.sub(r'[\s_\-#（）()]+', '', text).lower()
    if compact in {'0', 'na', 'n/a', 'none', 'null', 'xxx'}:
        return True
    if re.fullmatch(r'(?:备用|預備|预留|保留|spare|reserve|dựphòng)(?:\d+)?', compact, re.I):
        return True
    if re.fullmatch(r'\d+(?:-\d+)?', compact):
        return True
    return False


def _normalize_station_code(value: object) -> str:
    # Match the station number before removing the attached Vietnamese label;
    # exports commonly use values such as ``工位 Trạm 2-1``.
    text = _clean_reconstructed_value(value)
    match = re.search(r'工位(?:\s*[A-Za-zÀ-ỹ]+)*\s*(\d+)(?:\s*-\s*(\d+))?', text, re.I)
    if not match:
        return ''
    return f"工位{match.group(1)}" + (f"-{match.group(2)}" if match.group(2) is not None else '')


def _engineering_system(name: str) -> str:
    value = str(name or '')
    rules = [
        ('安全系统', ('急停', '安全门', '安全继电器', '光栅')),
        ('视觉检测系统', ('AOI', '视觉', '相机', '检测', '扫码')),
        ('气动系统', ('气缸', '夹爪', '真空', '吸盘', '顶升', '阻挡')),
        ('输送物流系统', ('载具', '运输板', '皮带', '送料', '收料', '上料', '下料')),
        ('运动控制系统', ('轴', '伺服', '电机', '升降机')),
        ('操作与报警', ('启动', '停止', '暂停', '复位', '报警', '故障', '提示')),
    ]
    for system, words in rules:
        if any(word in value for word in words):
            return system
    return '其他系统'



_AUTOMATION_ZH_VI = {
    '备用':'Dự phòng','预留':'Dự phòng','保留':'Dự phòng',
    '输入':'Đầu vào','输出':'Đầu ra','IO输入':'Đầu vào IO','IO输出':'Đầu ra IO',
    '原点':'Vị trí gốc','动点':'Vị trí tác động','正转':'Quay thuận','反转':'Quay ngược',
    '运行中':'Đang chạy','运行':'Chạy','输送':'Vận chuyển','电批名称':'Tên máy vặn vít',
    '位移传感器名称':'Tên cảm biến dịch chuyển','负限':'Giới hạn âm','正限':'Giới hạn dương',
    '操作条件不满足':'Điều kiện thao tác chưa được đáp ứng','已配置':'Đã cấu hình','未配置':'Chưa cấu hình',
    '工位':'Trạm làm việc','子模块':'Mô-đun con','所属系统':'Hệ thống','功能分类':'Phân loại chức năng',
    '输送物流系统':'Hệ thống vận chuyển và logistics','气动系统':'Hệ thống khí nén',
    '视觉检测系统':'Hệ thống kiểm tra thị giác','运动控制系统':'Hệ thống điều khiển chuyển động',
    '安全系统':'Hệ thống an toàn','操作与报警':'Vận hành và cảnh báo','通用设备系统':'Hệ thống thiết bị chung',
    '安全与急停':'An toàn và dừng khẩn cấp','操作按钮':'Nút thao tác','载具输送':'Vận chuyển đồ gá',
    '检测与视觉':'Kiểm tra và thị giác','气动与真空':'Khí nén và chân không','报警与状态':'Cảnh báo và trạng thái',
    '备用信号':'Tín hiệu dự phòng','其他':'Khác','运动轴':'Trục chuyển động','气缸':'Xi lanh','真空':'Chân không',
    '感应器':'Cảm biến','相机':'Camera','皮带线':'Băng tải','AOI/视觉':'AOI / Thị giác','安全门':'Cửa an toàn',
    '风扇':'Quạt','扫码器':'Máy quét mã','压力传感器':'Cảm biến áp suất','位移传感器':'Cảm biến dịch chuyển',
    '电批':'Tua vít điện','启动':'Khởi động','暂停':'Tạm dừng','停止':'Dừng','复位':'Đặt lại',
    '上升':'Nâng lên','下降':'Hạ xuống','伸出':'Đưa ra','缩回':'Thu về','松开':'Nhả ra','夹紧':'Kẹp chặt',
    '打开':'Mở','关闭':'Đóng','原位':'Vị trí gốc','动位':'Vị trí tác động','到位':'Đã đến vị trí',
    '上层线体':'Dây chuyền tầng trên','下层线体':'Dây chuyền tầng dưới','拆卸轴':'Trục tháo',
    '视觉交互':'Tương tác thị giác','检测轴':'Trục kiểm tra','载具输送':'Vận chuyển đồ gá',
    '上下料模组':'Mô-đun nạp/xả liệu','料盘搬运':'Vận chuyển khay vật liệu','上料':'Nạp liệu','下料':'Xả liệu',
    '升降机':'Thang nâng','轴':'Trục','检测模组':'Mô-đun kiểm tra','已删除':'Đã xóa',
    '中文':'Tiếng Trung','越南语':'Tiếng Việt','名称':'Tên','状态':'Trạng thái','类别':'Loại','编号':'Mã số',
    '地址':'Địa chỉ','序号':'STT','提示组':'Nhóm gợi ý','重复次数':'Số lần lặp','原位置':'Vị trí gốc',
}


def _glossary_vi(text: object) -> str:
    value=_clean_reconstructed_value(text)
    if not value:
        return ''
    if value in _AUTOMATION_ZH_VI:
        return _AUTOMATION_ZH_VI[value]
    # Translate common composite engineering labels deterministically.
    replacements=sorted(_AUTOMATION_ZH_VI.items(), key=lambda x: len(x[0]), reverse=True)
    result=value
    changed=False
    for zh,vi in replacements:
        if zh in result:
            result=result.replace(zh,vi); changed=True
    return result if changed and not _CJK_RE.search(result) else ''




_AUTOMATION_ZH_EN = {
    '操作条件不满足':'Operating conditions not met','已配置':'Configured','未配置':'Not configured',
    '工位':'Station','子模块':'Submodule','所属系统':'System','功能分类':'Function Category',
    '输送物流系统':'Conveyance and Logistics System','气动系统':'Pneumatic System',
    '视觉检测系统':'Vision Inspection System','运动控制系统':'Motion Control System',
    '安全系统':'Safety System','操作与报警':'Operation and Alarm','通用设备系统':'General Equipment System',
    '安全与急停':'Safety and Emergency Stop','操作按钮':'Operator Controls','载具输送':'Pallet Conveyance',
    '检测与视觉':'Inspection and Vision','气动与真空':'Pneumatics and Vacuum','报警与状态':'Alarms and Status',
    '备用信号':'Spare Signal','其他':'Other','其他系统':'Other System','运动轴':'Motion Axis','气缸':'Cylinder',
    '真空':'Vacuum','感应器':'Sensor','相机':'Camera','皮带线':'Belt Conveyor','AOI/视觉':'AOI / Vision',
    '安全门':'Safety Door','风扇':'Fan','扫码器':'Code Reader','压力传感器':'Pressure Sensor',
    '位移传感器':'Displacement Sensor','电批':'Electric Screwdriver','启动':'Start','暂停':'Pause',
    '停止':'Stop','复位':'Reset','上升':'Raise','下降':'Lower','伸出':'Extend','缩回':'Retract',
    '松开':'Release','夹紧':'Clamp','打开':'Open','关闭':'Close','原位':'Home Position','动位':'Actuated Position',
    '到位':'In Position','上层线体':'Upper Conveyor Line','下层线体':'Lower Conveyor Line','拆卸轴':'Disassembly Axis',
    '视觉交互':'Vision Interface','检测轴':'Inspection Axis','上下料模组':'Loading/Unloading Module',
    '料盘搬运':'Tray Transfer','上料':'Loading','下料':'Unloading','升降机':'Lifter','轴':'Axis',
    '检测模组':'Inspection Module','已删除':'Deleted','中文':'Chinese','英语':'English','越南语':'Vietnamese',
    '名称':'Name','状态':'Status','类别':'Category','编号':'ID','地址':'Address','序号':'No.',
    '提示组':'Message Group','重复次数':'Occurrences','原位置':'Source Cell',
}

_AUTOMATION_EN_TOKENS = {
    '安全继电器':'Safety Relay','安全门':'Safety Door','急停':'Emergency Stop','下料':'Unloading',
    '上料':'Loading','搬运':'Transfer','组装':'Assembly','翻转':'Flip','载具':'Pallet','治具':'Fixture',
    '料盘':'Tray','小车':'Shuttle','升降机':'Lifter','夹爪':'Gripper','气缸':'Cylinder','插销':'Pin',
    '顶升':'Lift','阻挡':'Stopper','伸出':'Extend','旋转':'Rotate','下压':'Press Down','定位':'Positioning',
    '真空':'Vacuum','皮带':'Conveyor','光栅':'Safety Light Curtain','旋钮':'Selector Switch','面板':'Panel',
    '产品':'Product','来料':'Incoming Material','进料':'Infeed','出料':'Outfeed','入料':'Loading',
    '流入':'Entry','流出':'Exit','检测':'Detection','有料':'Material Present','无料':'No Material',
    '高度':'Height','报警':'Alarm','感应器':'Sensor','感应':'Sensor','信号':'Signal','状态':'Status',
    '关闭':'Close','打开':'Open','启动':'Start','停止':'Stop','暂停':'Pause','复位':'Reset',
    '原位':'Home Position','动位':'Actuated Position','回位':'Retracted Position','出位':'Extended Position',
    '降位':'Lowered Position','升位':'Raised Position','松位':'Released Position','夹位':'Clamped Position',
    '到位':'In-position','左':'Left','右':'Right','前':'Front','后':'Rear','上':'Upper','下':'Lower',
    '中':'Center','层':'Level','侧':'Side','人工':'Manual','自动':'Auto','轴':'Axis','存料':'Material Buffer',
    '销钉':'Locating Pin','切换':'Switch','锁螺丝':'Screw Tightening','锁附':'Fastening','压力':'Pressure',
    '位移':'Displacement','手动模式':'Manual Mode','手动':'Manual','模式':'Mode','请切换到':'Please switch to',
    '未初始化':'Not initialized','初始化':'Initialization','操作':'Operation','故障中':'Fault active',
    '解除故障后':'after clearing the fault','故障':'Fault','弹窗条件':'Popup condition','完成':'Complete',
    '未选择':'Not selected','记忆清除':'Memory Clear','清料':'Material Clear','遮挡':'Blocked',
    '未使能':'Not enabled','使能':'Enable','未回原点':'Not homed','回原点':'Home','超负限':'Negative limit exceeded',
    '超正限':'Positive limit exceeded','报错':'Error','拍照':'Image capture','人工确认':'Manual confirmation',
    '扫产品码':'Scan product code','扫治具码':'Scan fixture code','扫描':'Scan','视觉引导':'Vision guidance',
    '请选择':'Please select','选择':'Select','不在':'Not in','请':'Please','安全':'Safety','上传':'Upload',
    '条件不满足':'Conditions not met','不满足':'Not met','真空信号':'Vacuum Signal','产品码':'Product Code',
    '治具码':'Fixture Code','系统':'System','模组':'Module','大弹簧':'Large Spring','小弹簧':'Small Spring',
    '出盘':'Tray Outfeed','进盘':'Tray Infeed','托盘':'Tray','满料':'Full','接近':'Proximity','取料':'Pick','送料':'Feed','收料':'Unload',
    '视觉':'Vision','反馈超时':'Feedback Timeout','码':'Code','拍照NG':'Image Capture NG',
}

def _glossary_en(text: object) -> str:
    value=_source_only_reconstructed_value(text)
    if not value:
        return ''
    if value in _AUTOMATION_ZH_EN:
        return _AUTOMATION_ZH_EN[value]
    # High-confidence PLC/HMI labels are composed deterministically so the same
    # Chinese source always receives the same engineering English.
    return _automation_en_fallback(value)


def _automation_en_fallback(text: object) -> str:
    value=_source_only_reconstructed_value(text)
    value=value.replace('载右具','载具右').replace('载左具','载具左')
    if not value or not _CJK_RE.search(value):
        return value
    result=value
    changed=False
    tokens={**_AUTOMATION_ZH_EN, **_AUTOMATION_EN_TOKENS}
    for zh,en in sorted(tokens.items(), key=lambda x: len(x[0]), reverse=True):
        if zh in result:
            result=result.replace(zh, f' {en} ')
            changed=True
    result=re.sub(r'\s+', ' ', result).strip(' -')
    if not changed or _CJK_RE.search(result):
        return ''
    return _normalize_english_label(result)


def _normalize_english_label(value: str) -> str:
    text=re.sub(r'\s+', ' ', str(value or '')).strip()
    replacements={
        'Lower Layer Sensor':'Lower-level Sensor','Full Material Sensor':'Material-full Sensor',
        'Entry Sensor':'Entry Sensor','Arrival Sensor':'In-position Sensor',
        'Cylinder Return':'Cylinder Retracted Position','Cylinder Extend':'Cylinder Extended Position',
        'Positioning 1 Return':'Positioning Cylinder 1 Retracted Position',
        'Positioning 1 Extend':'Positioning Cylinder 1 Extended Position',
        'Photo NG':'Image Capture NG','photo NG':'image capture NG',
    }
    for old,new in replacements.items():
        text=text.replace(old,new)
    text=re.sub(r'\bblanking\b', 'unloading', text, flags=re.I)
    text=re.sub(r'\bfeeding\b', 'loading', text, flags=re.I)
    text=re.sub(r'\bflow sensor\b', 'passage sensor', text, flags=re.I)
    text=re.sub(r'\bsensing\b', 'sensor', text, flags=re.I)
    text=re.sub(r'\barrival sensor\b', 'in-position sensor', text, flags=re.I)
    text=re.sub(r'\breturn position\b', 'retracted position', text, flags=re.I)
    text=re.sub(r'\bextend position\b', 'extended position', text, flags=re.I)
    # Engineering labels use title case while preserving common acronyms.
    words=[]
    for word in text.split(' '):
        if re.fullmatch(r'(?:PLC|HMI|IO|I/O|NG|OK|AOI|X|Y|Z|R|[XY]\d+)', word, re.I):
            words.append(word.upper())
        elif re.fullmatch(r'\d+', word):
            words.append(word)
        else:
            words.append(word[:1].upper()+word[1:].lower() if word else word)
    return ' '.join(words)


def _polish_automation_en(source: str, translated: str) -> str:
    fixed=_automation_en_fallback(source)
    # Prefer deterministic terminology for compact PLC/HMI names. For long
    # operator messages keep the provider sentence and normalize terminology.
    if fixed and len(source) <= 24 and not re.search(r'[。！？，,.!?]', source):
        return fixed
    text=_normalize_english_label(translated)
    terminology={
        r'\bcarrier\b':'Pallet', r'\bfixture carrier\b':'Pallet', r'\bblanking\b':'Unloading',
        r'\bfeeding\b':'Loading', r'\breset position\b':'Home Position',
        r'\borigin position\b':'Home Position', r'\bphoto(?:graph)?\b':'Image Capture',
    }
    for pattern,replacement in terminology.items():
        text=re.sub(pattern,replacement,text,flags=re.I)
    return re.sub(r'\s+', ' ', text).strip()


def _localize_reconstructed_headers(wb, target_code: str) -> None:
    """Localize all fixed reconstruction templates, including the overview.

    The overview used to stay Chinese even when the data sheets were exported as
    Chinese-English bilingual. Keep sheet identifiers stable for hyperlinks,
    but localize every visible title, label and explanatory value.
    """
    if target_code not in {'zh-en', 'zh-vi'}:
        return
    is_en = target_code == 'zh-en'
    header_map={
        'PLC输入信号':(['No.','Address','Chinese Function','English Function','Function Category','English Category','System','English System','Source Cell'] if is_en else None),
        '设备清单':(['Chinese Category','English Category','ID','Chinese Name','English Name','System','English System','Chinese Status','English Status'] if is_en else None),
        '气缸IO配置':(['Cylinder ID','Chinese Name','English Name','Home Input','Actuated Input','Chinese Home Action','English Home Action','Chinese Actuated Action','English Actuated Action','Home Output','Actuated Output','System','English System'] if is_en else None),
        '工位结构':(['Station ID','Chinese Station Name','English Station Name','Submodule ID','Chinese Submodule Name','English Submodule Name','System','English System'] if is_en else None),
        '操作提示':(['Message Group','Chinese Message','English Message','Occurrences','System','English System'] if is_en else None),
    }
    if is_en:
        for sheet_name,headers in header_map.items():
            if sheet_name not in wb.sheetnames or not headers:
                continue
            ws=wb[sheet_name]
            for col,label in enumerate(headers,1):
                ws.cell(1,col).value=label
                ws.cell(1,col).font=Font(name='Arial',size=10.5,bold=True,color='FFFFFF')

    if '文档概览' not in wb.sheetnames:
        return
    ws=wb['文档概览']
    if is_en:
        ws['A1']='项目\nItem'; ws['B1']='内容\nContent'
        label_map={
            '文档类型':'文档类型\nDocument Type',
            '整理方式':'整理方式\nOrganization Method',
            '无效数据处理':'无效数据处理\nInvalid Data Handling',
            '双语版式':'双语版式\nBilingual Layout',
            '分类表':'分类表\nCategory Sheet',
            '记录数量':'记录数量\nRecord Count',
            'PLC输入信号':'PLC输入信号\nPLC Input Signals',
            '设备清单':'设备清单\nEquipment List',
            '气缸IO配置':'气缸IO配置\nCylinder I/O Configuration',
            '工位结构':'工位结构\nStation Structure',
            '操作提示':'操作提示\nOperator Messages',
        }
        value_map={
            'PLC/HMI 自动化设备工程文档':'PLC/HMI 自动化设备工程文档\nPLC/HMI Automation Equipment Engineering Document',
            '按信号、设备、气缸、工位和提示信息分类汇总':'按信号、设备、气缸、工位和提示信息分类汇总\nOrganized by signals, equipment, cylinders, stations and operator messages',
            '已删除 #N/A、空白占位、备用项和无意义编号项':'已删除 #N/A、空白占位、备用项和无意义编号项\nRemoved #N/A values, blank placeholders, reserved entries and meaningless numbered items',
            '中文与越南语严格使用相邻独立列显示':'中文与英语严格使用相邻独立列显示\nChinese and English are displayed in adjacent dedicated columns',
            'Chinese and English are displayed in adjacent dedicated columns':'中文与英语严格使用相邻独立列显示\nChinese and English are displayed in adjacent dedicated columns',
        }
    else:
        ws['A1']='项目\nHạng mục'; ws['B1']='内容\nNội dung'
        label_map={
            '文档类型':'文档类型\nLoại tài liệu','整理方式':'整理方式\nPhương thức sắp xếp',
            '无效数据处理':'无效数据处理\nXử lý dữ liệu không hợp lệ','双语版式':'双语版式\nBố cục song ngữ',
            '分类表':'分类表\nBảng phân loại','记录数量':'记录数量\nSố lượng bản ghi',
        }
        value_map={
            'PLC/HMI 自动化设备工程文档':'PLC/HMI 自动化设备工程文档\nTài liệu kỹ thuật thiết bị tự động hóa PLC/HMI',
            '按信号、设备、气缸、工位和提示信息分类汇总':'按信号、设备、气缸、工位和提示信息分类汇总\nTổng hợp theo tín hiệu, thiết bị, xi lanh, trạm và thông báo vận hành',
            '已删除 #N/A、空白占位、备用项和无意义编号项':'已删除 #N/A、空白占位、备用项和无意义编号项\nĐã loại bỏ #N/A, ô giữ chỗ trống, mục dự phòng và mục đánh số vô nghĩa',
            '中文与越南语严格使用相邻独立列显示':'中文与越南语严格使用相邻独立列显示\nTiếng Trung và tiếng Việt được hiển thị trong các cột riêng liền kề',
        }
    for row in range(1,ws.max_row+1):
        left=str(ws.cell(row,1).value or '')
        left_zh=left.split('\n',1)[0].strip()
        if left_zh in label_map:
            ws.cell(row,1).value=label_map[left_zh]
        right=str(ws.cell(row,2).value or '')
        right_base=right.split('\n',1)[0].strip()
        if right in value_map:
            ws.cell(row,2).value=value_map[right]
        elif right_base in value_map:
            ws.cell(row,2).value=value_map[right_base]
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment=Alignment(vertical='center',wrap_text=True)
            if cell.row > 1 and cell.value not in (None,''):
                ws.row_dimensions[cell.row].height=max(ws.row_dimensions[cell.row].height or 26, 38)


def _existing_reconstructed_translation(value: object) -> str:
    """Return a usable existing Latin translation from a legacy bilingual cell."""
    text = _clean_reconstructed_value(value)
    if not text:
        return ''
    pair = _split_existing_bilingual_text(text)
    if not pair:
        return ''
    candidate = _clean_translation_candidate(pair[0], pair[1])
    return candidate if candidate and not _CJK_RE.search(candidate) else ''


_AUTOMATION_VI_TOKENS = {
    '备用':'dự phòng','预留':'dự phòng','保留':'dự phòng','IO输入':'đầu vào IO','IO输出':'đầu ra IO',
    '输入':'đầu vào','输出':'đầu ra','原点':'vị trí gốc','动点':'vị trí tác động',
    '正转':'quay thuận','反转':'quay ngược','运行中':'đang chạy','运行':'chạy','输送':'vận chuyển',
    '负限':'giới hạn âm','正限':'giới hạn dương','名称':'tên',
    '安全继电器':'rơ-le an toàn','安全门':'cửa an toàn','急停':'dừng khẩn cấp',
    '下料':'xả liệu','上料':'nạp liệu','搬运':'vận chuyển','组装':'lắp ráp','翻转':'lật',
    '载具':'đồ gá','料盘':'khay vật liệu','小车':'xe con','升降机':'thang nâng',
    '夹爪':'kẹp gắp','气缸':'xi lanh','插销':'chốt','顶升':'nâng đỡ','阻挡':'chặn',
    '伸出':'đưa ra','旋转':'xoay','下压':'ép xuống','定位':'định vị','真空':'chân không',
    '皮带':'băng tải','光栅':'rèm quang an toàn','旋钮':'núm xoay','面板':'bảng điều khiển',
    '产品':'sản phẩm','来料':'vật liệu đến','进料':'đầu vào','出料':'đầu ra','入料':'nạp liệu',
    '流入':'đi vào','流出':'đi ra','检测':'kiểm tra','有料':'có vật liệu','高度':'chiều cao',
    '报警':'cảnh báo','感应':'cảm biến','信号':'tín hiệu','状态':'trạng thái',
    '关闭':'đóng','打开':'mở','启动':'khởi động','停止':'dừng','暂停':'tạm dừng','复位':'đặt lại',
    '原位':'vị trí gốc','动位':'vị trí tác động','回位':'vị trí về','出位':'vị trí ra',
    '降位':'vị trí hạ','升位':'vị trí nâng','松位':'vị trí nhả','夹位':'vị trí kẹp',
    '到位':'đã đến vị trí','左':'trái','右':'phải','前':'trước','后':'sau','上':'trên','下':'dưới',
    '中':'giữa','层':'tầng','侧':'bên','人工':'thủ công','自动':'tự động','轴':'trục',
    '存料':'lưu vật liệu','销钉':'chốt định vị','切换':'chuyển đổi','锁螺丝':'siết vít',
    '锁附':'siết khóa','压力':'áp suất','位移':'độ dịch chuyển','手动模式':'chế độ thủ công',
    '手动':'thủ công','模式':'chế độ','请切换到':'vui lòng chuyển sang','未初始化':'chưa khởi tạo',
    '初始化':'khởi tạo','操作':'thao tác','故障中':'đang có lỗi','解除故障后':'sau khi xóa lỗi',
    '故障':'lỗi','弹窗条件':'điều kiện cửa sổ bật lên','完成':'hoàn thành','未选择':'chưa chọn',
    '记忆清除':'xóa bộ nhớ','清料':'dọn vật liệu','遮挡':'bị che chắn','未使能':'chưa được cho phép',
    '使能':'cho phép','未回原点':'chưa về điểm gốc','回原点':'về điểm gốc','超负限':'vượt giới hạn âm',
    '超正限':'vượt giới hạn dương','报错':'báo lỗi','拍照':'chụp ảnh','无料':'không có vật liệu',
    '人工确认':'xác nhận thủ công','扫产品码':'quét mã sản phẩm','扫治具码':'quét mã đồ gá',
    '扫描':'quét','视觉引导':'dẫn hướng thị giác','请选择':'vui lòng chọn','选择':'chọn',
    '不在':'không ở','请':'vui lòng','或':'hoặc','安全':'an toàn','一':'1','二':'2',
    '上传':'tải lên','条件不满足':'điều kiện chưa được đáp ứng','不满足':'chưa được đáp ứng',
    '下降':'hạ xuống','上升':'nâng lên','缩回':'thu về','伸出':'đưa ra','向':'hướng',
    '真空信号':'tín hiệu chân không','真空信':'tín hiệu chân không','治具':'đồ gá','产品码':'mã sản phẩm','治具码':'mã đồ gá',
    '其他系统':'hệ thống khác','其他':'khác','系统':'hệ thống','模组':'mô-đun',
    # V31.1 customer-acceptance terminology: alarm, PLC/HMI and station messages.
    '单步':'chạy từng bước','无料延时':'thời gian trễ không có vật liệu','进料阻挡':'chặn đầu vào',
    '出料阻挡':'chặn đầu ra','安全位':'vị trí an toàn','不在安全位':'không ở vị trí an toàn',
    '未运行':'chưa chạy','运行条件未满足':'điều kiện chạy chưa được đáp ứng',
    '控制器报警':'cảnh báo bộ điều khiển','驱动器报警':'cảnh báo bộ truyền động',
    '驱动报警':'cảnh báo bộ truyền động','从站报警':'cảnh báo trạm phụ',
    '反馈超时':'quá thời gian phản hồi','定位超时':'quá thời gian định vị',
    '出料超时':'quá thời gian xả liệu','进料超时':'quá thời gian nạp liệu',
    '连续NG报警':'cảnh báo NG liên tục','异常警告':'cảnh báo bất thường',
    '感应异常':'cảm biến bất thường','数据读取异常':'đọc dữ liệu bất thường',
    '视觉软件不在线':'phần mềm thị giác ngoại tuyến','视觉软件':'phần mềm thị giác',
    '视觉引导相机':'camera dẫn hướng thị giác','相机超时报警':'cảnh báo camera quá thời gian',
    '请检查':'vui lòng kiểm tra','请人工处理':'vui lòng xử lý thủ công',
    '请人工取走':'vui lòng lấy ra thủ công','请人工拿走':'vui lòng lấy đi thủ công',
    '请取走':'vui lòng lấy ra','请复位再操作':'vui lòng đặt lại rồi thao tác lại',
    '请操作到':'vui lòng đưa đến','未吸走':'chưa hút ra','吸出':'hút ra',
    '拆螺丝':'tháo vít','电批':'máy vặn vít điện','横移':'di chuyển ngang',
    '前横移':'di chuyển ngang phía trước','后横移':'di chuyển ngang phía sau',
    '侧前':'phía trước bên','侧后':'phía sau bên','前侧':'phía trước bên',
    '上流线':'dây chuyền phía trước','下层送料步进':'bộ cấp liệu bước tầng dưới',
    '步进控制器':'bộ điều khiển động cơ bước','步进':'động cơ bước',
    '料盘搬运':'vận chuyển khay vật liệu','取盘':'lấy khay','出盘':'đưa khay ra',
    '拍照标定位':'vị trí chuẩn chụp ảnh','拍照位':'vị trí chụp ảnh',
    '取料标定位':'vị trí chuẩn lấy vật liệu','放NG':'đặt NG','中位过渡':'chuyển tiếp vị trí giữa',
    '上升安全位':'vị trí an toàn khi nâng','放行位':'vị trí cho phép đi qua',
    '上料顶升':'nâng nạp liệu','下料顶升':'nâng xả liệu','顶升1':'cơ cấu nâng 1','顶升2':'cơ cấu nâng 2',
    '左顶升':'cơ cấu nâng trái','右顶升':'cơ cấu nâng phải','中顶升':'cơ cấu nâng giữa',
    '小车左下压':'xe con ép xuống bên trái','小车右下压':'xe con ép xuống bên phải',
    '取料定位':'định vị lấy liệu','取料托盘':'khay lấy liệu','组装下压':'ép lắp ráp',
    '出位感应异常':'cảm biến vị trí ra bất thường','回位感应异常':'cảm biến vị trí về bất thường',
    '原位感应异常':'cảm biến vị trí gốc bất thường','动位感应异常':'cảm biến vị trí tác động bất thường',
    '升位感应异常':'cảm biến vị trí nâng bất thường','降位感应异常':'cảm biến vị trí hạ bất thường',
    '不在上升位':'không ở vị trí nâng','不在下降位':'không ở vị trí hạ',
    '不在伸出位':'không ở vị trí đưa ra','不在动位位':'không ở vị trí tác động',
    '不在原位位':'không ở vị trí gốc','操作到上升位':'đưa đến vị trí nâng',
    '操作到下降位':'đưa đến vị trí hạ','操作到伸出位':'đưa đến vị trí đưa ra',
    '操作到动位位':'đưa đến vị trí tác động','操作到原位位':'đưa đến vị trí gốc',
    '物料状态标志':'cờ trạng thái vật liệu','状态标志':'cờ trạng thái',
    '无产品':'không có sản phẩm','有产品':'có sản phẩm','无载具':'không có đồ gá','有载具':'có đồ gá',
    '检测到':'phát hiện','未检测到':'không phát hiện','检测无物料':'phát hiện không có vật liệu',
    '检测有载具':'phát hiện có đồ gá','检测无载具':'phát hiện không có đồ gá',
    '匹配状态':'khớp trạng thái','状态不符':'trạng thái không khớp','感应信号状态':'trạng thái tín hiệu cảm biến',
    '危险区域':'khu vực nguy hiểm','初始化':'khởi tạo','干涉':'can thiệp',
    '有料':'có vật liệu','满料':'đầy vật liệu','空盘':'khay trống','上空盘':'nạp khay trống',
    '取走空盘':'lấy khay trống ra','减少上料盘':'giảm số khay nạp',
    '长时间无允许':'trong thời gian dài không có tín hiệu cho phép',
    '取弹簧信号':'tín hiệu lấy lò xo','是否上料完成':'việc nạp liệu đã hoàn tất hay chưa',
    '高度或料盘异常':'chiều cao hoặc khay vật liệu bất thường',
    '超出上升限制位':'vượt quá vị trí giới hạn nâng','超出':'vượt quá',
    '移动量超过保护距离':'quãng đường di chuyển vượt khoảng cách bảo vệ',
    '原点感应是否异常':'cảm biến gốc có bất thường hay không','参数设置错误':'cài đặt tham số sai',
    '位置无法到达':'không thể đến vị trí','定位偏差设定':'cài đặt sai lệch định vị',
    '超正极限':'vượt giới hạn dương','超负极限':'vượt giới hạn âm',
    '从站是否断电或掉线':'trạm phụ có mất điện hoặc mất kết nối hay không',
    '真空复检到有真空信号':'kiểm tra lại phát hiện có tín hiệu chân không',
    '破真空报警':'cảnh báo phá chân không','真空是否异常':'chân không có bất thường hay không',
    '底部检测':'kiểm tra đáy','反馈结果超时':'quá thời gian phản hồi kết quả',
    '次数过多':'số lần quá nhiều','压力上限':'giới hạn trên áp suất','当前下料盘数':'số khay xả hiện tại',
    '视觉触发':'kích hoạt thị giác','文本':'văn bản','操作-':'thao tác - ',
    '上中下层':'tầng trên, giữa và dưới','上中层':'tầng trên và giữa','上层':'tầng trên',
    '下层':'tầng dưới','右工位':'trạm bên phải','左工位':'trạm bên trái',
    '检测工位':'trạm kiểm tra','NG工位':'trạm NG','NG模组':'mô-đun NG',
    '右载具':'đồ gá bên phải','左载具':'đồ gá bên trái','载具右工位':'trạm đồ gá bên phải',
    '载具左工位':'trạm đồ gá bên trái','检测流程':'quy trình kiểm tra',
    '插销气缸':'xi lanh chốt','到位信号':'tín hiệu đã đến vị trí',
    '压力':'áp suất','位移数据':'dữ liệu dịch chuyển','二位移':'dịch chuyển số 2',
    '正转信号':'tín hiệu quay thuận','反转信号':'tín hiệu quay ngược',
    '物料':'vật liệu','料盘':'khay vật liệu','弹簧':'lò xo','大弹簧':'lò xo lớn','小弹簧':'lò xo nhỏ',
    '限制位':'vị trí giới hạn','保护距离':'khoảng cách bảo vệ','参数':'tham số',
    '断电':'mất điện','掉线':'mất kết nối','在线':'trực tuyến','复检':'kiểm tra lại',
    '结果':'kết quả','次数':'số lần','过多':'quá nhiều','标志':'cờ',
    '流程':'quy trình','条件':'điều kiện','允许':'cho phép','完成':'hoàn tất',
    '未关闭':'chưa đóng','不符':'không khớp','未':'chưa','在':'ở','有':'có','请检':'vui lòng kiểm tra',
    '和':'và','与':'và','顶':'phía trên',
    '检查':'kiểm tra','请按':'vui lòng nhấn','按钮':'nút','按':'nhấn',
    '底部':'phía đáy','底':'đáy','部':'phần','处理':'xử lý','人工检查':'kiểm tra thủ công',
    '无空盘':'không có khay trống','上空盘':'nạp khay trống','无产品检测信号':'không có tín hiệu phát hiện sản phẩm',
    '组装状态':'trạng thái lắp ráp','信号':'tín hiệu','长时间':'trong thời gian dài',
    '取弹簧':'lấy lò xo','是否':'hay không','上料完成':'nạp liệu hoàn tất','请处理':'vui lòng xử lý',
    '未吸走':'chưa được hút ra','超时报警':'cảnh báo quá thời gian','连续NG':'NG liên tục',
    '取料位':'vị trí lấy liệu','推料位':'vị trí đẩy liệu','上料位':'vị trí nạp liệu',
    '下料盘数':'số khay xả','上料盘':'khay nạp','下料盘':'khay xả',
}

def _normalize_vietnamese_label(value: str) -> str:
    text = re.sub(r"\s*_\s*", "_", str(value or ""))
    text = re.sub(r"\s+", " ", text).strip(" _-—")
    if not text:
        return ""

    def capitalize_segment(segment: str) -> str:
        for index, char in enumerate(segment):
            if char.isalpha():
                return segment[:index] + char.upper() + segment[index + 1:]
        return segment

    # Underscores delimit PLC label fields; capitalize each field for readable
    # output such as ``Đầu vào IO_Vị trí gốc``.
    return "_".join(capitalize_segment(part) for part in text.split("_"))


_HMI_EXACT_ZH_VI = {
    'IO显示行数':'Số hàng hiển thị I/O','IO显示列数':'Số cột hiển thị I/O',
    'IO地址显示剔除几位':'Số chữ số bị loại khi hiển thị địa chỉ I/O',
    '相对定位':'Định vị tương đối','绝对定位':'Định vị tuyệt đối',
    '页面-参数名':'Tên tham số trang','系统设置':'Cài đặt hệ thống',
    '延时设置':'Cài đặt thời gian trễ','伺服参数':'Tham số servo',
    '气缸参数':'Tham số xi lanh','真空参数':'Tham số chân không',
    '其他设置':'Cài đặt khác','其它设置':'Cài đặt khác','HMI设置':'Cài đặt HMI',
    '产能统计':'Thống kê sản lượng','时间统计':'Thống kê thời gian',
    '统计设置':'Cài đặt thống kê','其它监视':'Giám sát khác',
    '检测记录':'Bản ghi kiểm tra','单工位操作':'Vận hành từng trạm',
    '联机信号':'Tín hiệu liên máy','安全门锁':'Khóa cửa an toàn',
    '退出':'Thoát','关闭':'Đóng','下一页':'Trang sau','上一页':'Trang trước',
    '当前用户':'Người dùng hiện tại','用户':'Người dùng','密码':'Mật khẩu','新密码':'Mật khẩu mới',
    '信息显示':'Hiển thị thông tin','照明灯':'Đèn chiếu sáng','生产总数':'Tổng sản lượng',
    'NG数量':'Số lượng NG','良率':'Tỷ lệ đạt','图形显示':'Hiển thị biểu đồ',
    '列表显示':'Hiển thị danh sách','日期选择':'Chọn ngày','总数':'Tổng số',
    '运行时间':'Thời gian chạy','异常时间':'Thời gian bất thường','待料时间':'Thời gian chờ liệu',
    '时间段':'Khoảng thời gian','产能':'Sản lượng','合计':'Tổng cộng','达成率':'Tỷ lệ hoàn thành',
    '稼动率':'Tỷ lệ vận hành','统计项目':'Hạng mục thống kê','数量':'Số lượng',
    '百分比':'Tỷ lệ phần trăm','投入总数':'Tổng số đầu vào','平均':'Trung bình',
    '开始统计时间':'Thời gian bắt đầu thống kê','目标':'Mục tiêu',
    '图形显示设置':'Cài đặt hiển thị biểu đồ','最大值':'Giá trị lớn nhất','最小值':'Giá trị nhỏ nhất',
    '电池电压':'Điện áp pin','CPU使用率':'Mức sử dụng CPU','可用空间':'Dung lượng khả dụng',
    '光标':'Con trỏ','声音':'Âm thanh','时间设置':'Cài đặt thời gian',
    '年':'Năm','月':'Tháng','日':'Ngày','时':'Giờ','分':'Phút','秒':'Giây',
    '用户注销时间':'Thời gian đăng xuất người dùng','屏幕保护时间':'Thời gian bảo vệ màn hình',
    '背光节能时间':'Thời gian tiết kiệm đèn nền','背光亮度设置':'Cài đặt độ sáng đèn nền',
    '日期':'Ngày','时间':'Thời gian','报警事件':'Sự kiện cảnh báo','累计时间':'Thời gian tích lũy',
    '当前报警显示':'Hiển thị cảnh báo hiện tại','报警记录显示':'Hiển thị lịch sử cảnh báo',
    '已恢复':'Đã khôi phục','当前报警':'Cảnh báo hiện tại','已确认':'Đã xác nhận',
    '气缸手动保护':'Bảo vệ thao tác tay xi lanh','轴手动保护':'Bảo vệ thao tác tay trục',
    '安全门保护':'Bảo vệ cửa an toàn','运行模式':'Chế độ vận hành','前机':'Máy trước','后机':'Máy sau',
    '允许偏差':'Sai lệch cho phép','回零高速':'Tốc độ về gốc cao','回零低速':'Tốc độ về gốc thấp',
    '原点屏蔽':'Che chắn điểm gốc','动点屏蔽':'Che chắn điểm tác động','真空屏蔽':'Che chắn chân không',
    '当前位置':'Vị trí hiện tại','当前速度':'Tốc độ hiện tại','报警代码':'Mã cảnh báo',
    '出错代码':'Mã lỗi','手动速度':'Tốc độ thủ công','定位位置':'Vị trí định vị','自动速度':'Tốc độ tự động',
    '位置':'Vị trí','初始化窗口':'Cửa sổ khởi tạo','初始化清除模式':'Chế độ xóa khởi tạo',
    '人工确认':'Xác nhận thủ công','操作提示':'Hướng dẫn thao tác','光源':'Nguồn sáng',
    '触发模式':'Chế độ kích hoạt','触发间隔':'Khoảng thời gian kích hoạt','触发次数':'Số lần kích hoạt',
    '检测工位':'Trạm kiểm tra','开始延时':'Thời gian trễ bắt đầu','结束延时':'Thời gian trễ kết thúc',
    '视觉反馈超时时间':'Thời gian chờ phản hồi thị giác','有料检测延时':'Thời gian trễ phát hiện có liệu',
    '无料检测延时':'Thời gian trễ phát hiện không có liệu','线体名称':'Tên dây chuyền',
    '当前存料':'Lượng vật liệu hiện tại','最大存料':'Lượng vật liệu tối đa',
    '出料延时':'Thời gian trễ xả liệu','出料间隔':'Khoảng cách xả liệu',
    '需求数量':'Số lượng yêu cầu','出料超时':'Quá thời gian xả liệu',
    '设置':'Cài đặt','轴报警信息':'Thông tin cảnh báo trục',
    '密码错误':'Mật khẩu sai','权限提示':'Thông báo quyền hạn','网络异常':'Mạng bất thường',
    '注销时间':'Thời gian đăng xuất','屏保时间':'Thời gian bảo vệ màn hình',
    '背光时间':'Thời gian đèn nền','亮度设置':'Cài đặt độ sáng',
    '轴当前位置':'Vị trí trục hiện tại','轴当前速度':'Tốc độ trục hiện tại',
    '轴报警代码':'Mã cảnh báo trục','轴出错代码':'Mã lỗi trục',
    '轴手动速度':'Tốc độ trục thủ công','轴定位位置':'Vị trí định vị trục',
    '轴自动速度':'Tốc độ trục tự động','反馈超时时间':'Thời gian chờ phản hồi',
    '连接状态':'Trạng thái kết nối','到位延时':'Thời gian trễ đến vị trí',
    '满料延时':'Thời gian trễ đầy liệu','阻挡顶升延时':'Thời gian trễ chặn nâng',
    '真空IO输出-吸':'Đầu ra I/O chân không - hút','真空IO输出-破':'Đầu ra I/O chân không - phá',
    '皮带线IO_运转中':'I/O băng tải_đang chạy',
    '密码错误清重新输入':'Mật khẩu sai, vui lòng nhập lại',
    '您没有操作权限！！请先登陆！！':'Bạn không có quyền thao tác! Vui lòng đăng nhập trước!',
    'PLC连接异常':'Kết nối PLC bất thường','网络连接异常，请检查':'Kết nối mạng bất thường, vui lòng kiểm tra',
    '加速度':'Gia tốc','减速度':'Giảm tốc','回零位置':'Vị trí về gốc',
    '回零超时':'Quá thời gian về gốc','回零限位':'Giới hạn về gốc',
    '报警延时':'Thời gian trễ cảnh báo','原点延时':'Thời gian trễ vị trí gốc',
    '动点延时':'Thời gian trễ vị trí tác động','复检延时':'Thời gian trễ kiểm tra lại',
    '真空延时':'Thời gian trễ chân không','吹气延时':'Thời gian trễ thổi khí',
    '相机触发关闭延时':'Thời gian trễ tắt kích hoạt camera',
    '光源触发关闭延时':'Thời gian trễ tắt kích hoạt nguồn sáng',
    '相机触发间隔':'Khoảng thời gian kích hoạt camera','未连接':'Chưa kết nối','已连接':'Đã kết nối',
    '二维码':'Mã QR','MES软件':'Phần mềm MES','目标位置':'Vị trí mục tiêu',
    '急停报警':'Báo động dừng khẩn cấp','报警':'Cảnh báo','工位':'Trạm','序号':'STT','初始化':'Khởi tạo',
    '上升':'Nâng lên','下降':'Hạ xuống','伸出':'Đưa ra','缩回':'Thu về',
    '原位':'Vị trí gốc','动位':'Vị trí tác động','清零':'Đặt về 0',
}

_HMI_PREFIX_RE = re.compile(r'^(?:页面|文本|操作)-(.+)$')
_IO_CODE_RE = re.compile(r'^(?P<code>(?:[XYMDWRSTCZ]|SD|SM|AX|CY|SE|BL|SC|DS|PS|VA)\d+(?:\.\d+)?)\s*(?P<body>.+)$', re.I)
_AXIS_NAME_RE = re.compile(r'^轴(?P<index>\d+)位置名称$')
_POSITION_LABEL_RE = re.compile(r'^(?P<code>P(?P<num>\d+))-(?P<body>.+)$', re.I)
_AXIS_CONDITION_RE = re.compile(r'^(?P<code>AX\d+)\s*(?P<body>.+?)操作条件不满足$', re.I)

def _automation_vi_fallback(text: object) -> str:
    """Translate high-confidence PLC/HMI labels locally before any AI request.

    V39 expands the deterministic path from token replacement to structured HMI
    templates.  Presentation prefixes, I/O addresses, axis condition alarms and
    position labels are composed locally, dramatically shrinking provider input.
    """
    value = _source_only_reconstructed_value(text)
    value = value.replace('载右具', '载具右').strip()
    if not value or not _CJK_RE.search(value):
        return value

    exact = _HMI_EXACT_ZH_VI.get(value)
    if exact:
        return exact

    axis_label = re.fullmatch(r'(.+?)([XYZR])轴', value, flags=re.I)
    if axis_label:
        head = _automation_vi_fallback(axis_label.group(1))
        if head and not _CJK_RE.search(head):
            return f"{head} trục {axis_label.group(2).upper()}"

    prefix_match = _HMI_PREFIX_RE.match(value)
    if prefix_match:
        body = prefix_match.group(1).strip()
        translated = _HMI_EXACT_ZH_VI.get(body) or _automation_vi_fallback(body)
        if translated and not _CJK_RE.search(translated):
            return translated

    axis_name = _AXIS_NAME_RE.match(value)
    if axis_name:
        return f"Tên vị trí trục {axis_name.group('index')}"

    axis_condition = _AXIS_CONDITION_RE.match(value)
    if axis_condition:
        body = _automation_vi_fallback(axis_condition.group('body'))
        if body and not _CJK_RE.search(body):
            return f"{axis_condition.group('code')} Không đáp ứng điều kiện vận hành {body}"

    position = _POSITION_LABEL_RE.match(value)
    if position:
        body = position.group('body').strip('- ')
        body = re.sub(rf'P{re.escape(position.group("num"))}$', '', body, flags=re.I).strip()
        translated = _HMI_EXACT_ZH_VI.get(body) or _automation_vi_fallback(body)
        if translated and not _CJK_RE.search(translated):
            return f"{position.group('code')}-{translated}"

    code_match = _IO_CODE_RE.match(value)
    if code_match:
        body = code_match.group('body').strip()
        translated = _HMI_EXACT_ZH_VI.get(body) or _automation_vi_fallback(body)
        if translated and not _CJK_RE.search(translated):
            return f"{code_match.group('code')} {translated}"

    result=value
    changed=False
    extra_tokens = {
        '三色灯蜂鸣器':'còi đèn ba màu','三色灯红':'đèn ba màu đỏ',
        '三色灯黄':'đèn ba màu vàng','三色灯绿':'đèn ba màu xanh',
        '启动灯':'đèn khởi động','停止灯':'đèn dừng','暂停灯':'đèn tạm dừng','复位灯':'đèn đặt lại',
        '刹车':'phanh','吸真空':'hút chân không','破真空':'phá chân không',
        '松开':'mở kẹp','夹紧':'kẹp chặt','动作':'hoạt động','位置名称':'tên vị trí',
        '显示行数':'số hàng hiển thị','显示列数':'số cột hiển thị','地址显示':'hiển thị địa chỉ',
        '剔除几位':'số chữ số loại bỏ','放料':'đặt liệu','接料':'nhận liệu','送料':'cấp liệu',
        '取料':'lấy liệu','放盘':'đặt khay','接盘':'nhận khay','送盘':'đưa khay',
        '尾盘':'khay cuối','首盘':'khay đầu','偏移值':'giá trị bù','上升限制':'giới hạn nâng',
        '下降限制':'giới hạn hạ','过渡点':'điểm chuyển tiếp','精确点位':'vị trí chính xác',
        '位移点位':'vị trí dịch chuyển','检测点位':'vị trí kiểm tra','拍板码':'chụp mã bảng',
        '水冷板':'tấm làm mát bằng nước','设备名称':'tên thiết bị','拍照点':'điểm chụp ảnh',
        '过渡':'chuyển tiếp','上位':'vị trí trên','中位':'vị trí giữa','下位':'vị trí dưới',
        '左位':'vị trí trái','右位':'vị trí phải','点位':'vị trí','放料点':'điểm đặt liệu',
        '取盘位':'vị trí lấy khay','放盘位':'vị trí đặt khay','接盘位':'vị trí nhận khay',
        '送盘位':'vị trí đưa khay','送料位':'vị trí cấp liệu','接料位':'vị trí nhận liệu',
        'NG料':'vật liệu NG','放':'đặt','料':'vật liệu',
        '灯':'đèn','位':'vị trí','点':'điểm',
    }
    token_map = {**_AUTOMATION_ZH_VI, **_AUTOMATION_VI_TOKENS, **extra_tokens}
    for zh,vi in sorted(token_map.items(), key=lambda x: len(x[0]), reverse=True):
        if zh in result:
            result=result.replace(zh, f' {vi} ')
            changed=True
    result=re.sub(r'[，。！!；;]+$', '', result)
    result=_normalize_vietnamese_label(result)
    return result if changed and not _CJK_RE.search(result) else ''

def _bilingual_header(zh: str, vi: str) -> str:
    return f'{zh}\n{vi}'


def _style_reconstructed_sheet(ws, widths: list[float], table_color: str = '1F4E78') -> None:
    header_fill = PatternFill('solid', fgColor=table_color)
    alt_fill = PatternFill('solid', fgColor='F3F7FB')
    thin = Side(style='thin', color='D9E2F3')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for cell in ws[1]:
        if cell.value not in (None, ''):
            cell.font = Font(name='Microsoft YaHei', size=10.5, bold=True, color='FFFFFF')
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.border = border
    ws.row_dimensions[1].height = 44
    for r, row in enumerate(ws.iter_rows(min_row=2), start=2):
        has_value = False
        max_lines = 1
        for cell in row:
            if cell.value not in (None, ''):
                has_value = True
                max_lines = max(max_lines, str(cell.value).count('\n') + 1)
            cell.font = Font(name='Microsoft YaHei', size=10.5)
            cell.alignment = Alignment(vertical='center', wrap_text=True)
            cell.border = border
            if r % 2 == 0:
                cell.fill = alt_fill
        if has_value:
            ws.row_dimensions[r].height = max(26, min(78, 19 * max_lines))
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    ws.sheet_view.showGridLines = False
    ws.sheet_view.zoomScale = 100
    ws.sheet_properties.pageSetUpPr.fitToPage = False
    ws.page_setup.fitToWidth = 0
    ws.page_setup.fitToHeight = 0
    ws.page_setup.scale = 100
    ws.page_setup.orientation = 'landscape'
    ws.page_margins.left = 0.25
    ws.page_margins.right = 0.25


def _reconstruct_plc_configuration(source: Path, destination: Path, callback: ProgressCallback | None = None) -> dict[str, Any] | None:
    """Rebuild PLC/HMI matrices into concise bilingual engineering tables."""
    try:
        wb = load_workbook(source, data_only=False, read_only=False)
    except Exception:
        return None
    try:
        if not wb.worksheets:
            return None
        ws = wb.worksheets[0]
        probe = {_source_only_reconstructed_value(ws.cell(r, 1).value) for r in range(1, min(ws.max_row, 180) + 1)}
        required = {'输入名称', '轴名称', '气缸名称', '工位名称'}
        if len(required & probe) < 3:
            return None

        _update(callback, 14, 'cleanup', '识别为 PLC/HMI 配置表，正在提取、归类并建立企业双语术语')
        from openpyxl import Workbook
        out = Workbook()
        overview = out.active
        overview.title = '文档概览'
        overview.append([_bilingual_header('项目','Hạng mục'), _bilingual_header('内容','Nội dung')])

        plc_rows=[]
        for r in range(4, min(ws.max_row, 35) + 1):
            for c in range(2, min(ws.max_column, 256) + 1):
                code, raw_name = _split_code_name(ws.cell(r, c).value)
                name=_source_only_reconstructed_value(raw_name)
                if code.startswith('X') and not _is_meaningless_reconstructed_value(name):
                    category=_classify_plc_function(name); system=_engineering_system(name)
                    plc_rows.append([code,name,_glossary_vi(name),category,_glossary_vi(category),system,_glossary_vi(system),f'{get_column_letter(c)}{r}'])
        # An address identifies one physical signal.  Keep the first meaningful
        # occurrence and discard duplicated export blocks.
        plc_unique={}
        for row in plc_rows:
            plc_unique.setdefault(row[0], row)
        plc_rows=list(plc_unique.values())

        equipment_rows=[]
        equipment_map={'轴名称':'运动轴','气缸名称':'气缸','真空名称':'真空','感应器名称':'感应器','相机名称':'相机','皮带线名称':'皮带线','AOI名称':'AOI/视觉','安全门名称':'安全门','风扇名称':'风扇','扫码器名称':'扫码器','压力传感器名称':'压力传感器','位移传感器名称':'位移传感器','电批名称':'电批'}
        for r in range(1,min(ws.max_row,100)+1):
            category=equipment_map.get(_source_only_reconstructed_value(ws.cell(r,1).value))
            if not category: continue
            seen=set()
            for c in range(2,min(ws.max_column,256)+1):
                code,raw_name=_split_code_name(ws.cell(r,c).value); name=_source_only_reconstructed_value(raw_name)
                if not (code or name) or _is_meaningless_reconstructed_value(name or code): continue
                key=(category,code,name)
                if key in seen: continue
                seen.add(key)
                display=name or code; system=_engineering_system(category+display)
                equipment_rows.append([category,_glossary_vi(category),code,display,_glossary_vi(display),system,_glossary_vi(system),'已配置',_glossary_vi('已配置')])

        cylinder_rows=[]
        for c in range(2,min(ws.max_column,256)+1):
            code,raw_name=_split_code_name(ws.cell(37,c).value); name=_source_only_reconstructed_value(raw_name)
            if not (code or name) or _is_meaningless_reconstructed_value(name or code): continue
            vals=[_source_only_reconstructed_value(ws.cell(rr,c).value) for rr in range(50,56)]
            if not any(vals) and not name: continue
            system=_engineering_system(name+'气缸')
            cylinder_rows.append([code,name,_glossary_vi(name),vals[0],vals[1],vals[2],_glossary_vi(vals[2]),vals[3],_glossary_vi(vals[3]),vals[4],vals[5],system,_glossary_vi(system)])

        station_rows=[]
        current_code=current_name=''
        station_seen=set()
        for r in range(86,min(ws.max_row,320)+1):
            code=_normalize_station_code(ws.cell(r,1).value)
            name=_source_only_reconstructed_value(ws.cell(r,2).value)
            if not code or _is_meaningless_reconstructed_value(name): continue
            if re.fullmatch(r'工位\d+',code):
                current_code,current_name=code,name
            elif re.fullmatch(r'工位\d+-\d+',code):
                if not current_code: continue
                key=(current_code,code,name)
                if key in station_seen: continue
                station_seen.add(key)
                system=_engineering_system(current_name+name)
                station_rows.append([current_code,current_name,_glossary_vi(current_name),code,name,_glossary_vi(name),system,_glossary_vi(system)])
        with_children={r[0] for r in station_rows}
        for r in range(86,min(ws.max_row,320)+1):
            code=_normalize_station_code(ws.cell(r,1).value); name=_source_only_reconstructed_value(ws.cell(r,2).value)
            if re.fullmatch(r'工位\d+',code or '') and code not in with_children and not _is_meaningless_reconstructed_value(name):
                system=_engineering_system(name)
                station_rows.append([code,name,_glossary_vi(name),'','','',system,_glossary_vi(system)])

        tip_counter={}
        for r in range(68,min(ws.max_row,180)+1):
            key=_clean_reconstructed_value(ws.cell(r,1).value)
            key_match=re.match(r'^(Tip\d+)_Title',key,re.I)
            if not key_match: continue
            group=key_match.group(1)
            for c in range(2,min(ws.max_column,256)+1):
                value=_source_only_reconstructed_value(ws.cell(r,c).value)
                if _is_meaningless_reconstructed_value(value): continue
                tip_counter[(group,value)]=tip_counter.get((group,value),0)+1
        tip_rows=[]
        for (g,msg),count in tip_counter.items():
            system=_engineering_system(msg)
            tip_rows.append([g,msg,_glossary_vi(msg),count,system,_glossary_vi(system)])

        counts={'PLC输入信号':len(plc_rows),'设备清单':len(equipment_rows),'气缸IO配置':len(cylinder_rows),'工位结构':len(station_rows),'操作提示':len(tip_rows)}
        overview_rows=[
            ('文档类型','PLC/HMI 自动化设备工程文档'),('整理方式','按信号、设备、气缸、工位和提示信息分类汇总'),
            ('无效数据处理','已删除 #N/A、空白占位、备用项和无意义编号项'),('双语版式','中文与越南语严格使用相邻独立列显示'),
        ]
        for left,right in overview_rows: overview.append([f'{left}\n{_glossary_vi(left)}',right])
        overview.append([_bilingual_header('分类表','Bảng phân loại'),_bilingual_header('记录数量','Số lượng bản ghi')])
        for name,count in counts.items():
            overview.append([name,count]); overview.cell(overview.max_row,1).hyperlink=f"#'{name}'!A1"; overview.cell(overview.max_row,1).style='Hyperlink'

        plc=out.create_sheet('PLC输入信号'); plc.append([_bilingual_header('序号','STT'),_bilingual_header('地址','Địa chỉ'),_bilingual_header('中文功能','Chức năng tiếng Trung'),_bilingual_header('越南语功能','Chức năng tiếng Việt'),_bilingual_header('功能分类','Phân loại chức năng'),_bilingual_header('越南语分类','Phân loại tiếng Việt'),_bilingual_header('所属系统','Hệ thống'),_bilingual_header('越南语系统','Hệ thống tiếng Việt'),_bilingual_header('原位置','Vị trí gốc')])
        for i,row in enumerate(plc_rows,1): plc.append([i,*row])
        equipment=out.create_sheet('设备清单'); equipment.append([_bilingual_header('中文类别','Loại tiếng Trung'),_bilingual_header('越南语类别','Loại tiếng Việt'),_bilingual_header('编号','Mã số'),_bilingual_header('中文名称','Tên tiếng Trung'),_bilingual_header('越南语名称','Tên tiếng Việt'),_bilingual_header('所属系统','Hệ thống'),_bilingual_header('越南语系统','Hệ thống tiếng Việt'),_bilingual_header('中文状态','Trạng thái tiếng Trung'),_bilingual_header('越南语状态','Trạng thái tiếng Việt')])
        for row in equipment_rows: equipment.append(row)
        cylinder=out.create_sheet('气缸IO配置'); cylinder.append([_bilingual_header('气缸编号','Mã xi lanh'),_bilingual_header('中文名称','Tên tiếng Trung'),_bilingual_header('越南语名称','Tên tiếng Việt'),_bilingual_header('原位输入','Đầu vào vị trí gốc'),_bilingual_header('动位输入','Đầu vào vị trí tác động'),_bilingual_header('中文原位动作','Thao tác gốc tiếng Trung'),_bilingual_header('越南语原位动作','Thao tác gốc tiếng Việt'),_bilingual_header('中文动位动作','Thao tác động tiếng Trung'),_bilingual_header('越南语动位动作','Thao tác động tiếng Việt'),_bilingual_header('原位输出','Đầu ra vị trí gốc'),_bilingual_header('动位输出','Đầu ra vị trí tác động'),_bilingual_header('所属系统','Hệ thống'),_bilingual_header('越南语系统','Hệ thống tiếng Việt')])
        for row in cylinder_rows: cylinder.append(row)
        stations=out.create_sheet('工位结构'); stations.append([_bilingual_header('工位编号','Mã trạm'),_bilingual_header('中文工位名称','Tên trạm tiếng Trung'),_bilingual_header('越南语工位名称','Tên trạm tiếng Việt'),_bilingual_header('子模块编号','Mã mô-đun con'),_bilingual_header('中文子模块名称','Tên mô-đun tiếng Trung'),_bilingual_header('越南语子模块名称','Tên mô-đun tiếng Việt'),_bilingual_header('所属系统','Hệ thống'),_bilingual_header('越南语系统','Hệ thống tiếng Việt')])
        for row in station_rows: stations.append(row)
        tips=out.create_sheet('操作提示'); tips.append([_bilingual_header('提示组','Nhóm gợi ý'),_bilingual_header('中文提示','Gợi ý tiếng Trung'),_bilingual_header('越南语提示','Gợi ý tiếng Việt'),_bilingual_header('重复次数','Số lần lặp'),_bilingual_header('所属系统','Hệ thống'),_bilingual_header('越南语系统','Hệ thống tiếng Việt')])
        for row in tip_rows: tips.append(row)

        _style_reconstructed_sheet(overview,[26,76],'1F4E78')
        _style_reconstructed_sheet(plc,[8,14,30,34,20,24,20,28,14],'2F75B5')
        _style_reconstructed_sheet(equipment,[18,22,14,30,34,20,28,16,20],'548235')
        _style_reconstructed_sheet(cylinder,[14,26,30,15,15,18,22,18,22,15,15,20,28],'8064A2')
        _style_reconstructed_sheet(stations,[14,26,30,16,28,32,20,28],'C55A11')
        _style_reconstructed_sheet(tips,[16,38,42,12,20,28],'BF9000')

        # Drop empty rows/columns and validate meaningful output before saving.
        for sheet in out.worksheets:
            while sheet.max_row > 1 and all(sheet.cell(sheet.max_row,c).value in (None,'') for c in range(1,sheet.max_column+1)):
                sheet.delete_rows(sheet.max_row)
            while sheet.max_column > 1 and all(sheet.cell(r,sheet.max_column).value in (None,'') for r in range(1,sheet.max_row+1)):
                sheet.delete_cols(sheet.max_column)

        destination.parent.mkdir(parents=True, exist_ok=True)
        out.save(destination); out.close()
        check=load_workbook(destination,read_only=True,data_only=False)
        try:
            actual={sh.title:max(0,sh.max_row-1) for sh in check.worksheets}
            if not any(actual.get(name,0) for name in counts):
                raise RuntimeError('企业重构结果为空，已阻止交付')
        finally: check.close()
        _update(callback,92,'cleanup',f"智能重构完成：5 张分类表；PLC {counts['PLC输入信号']} 条；术语库已预翻译固定动作、状态和系统")
        return {'mode':'enterprise_reconstruction','document_type':'plc_hmi_configuration','sheets':len(actual),'records':actual,'structure_changed':True,'summary_counts':counts,'terminology_version':'21.3'}
    finally:
        wb.close()

def _clean_xlsx(source: Path, destination: Path, callback: ProgressCallback | None = None) -> dict[str, Any]:
    reconstructed = _reconstruct_plc_configuration(source, destination, callback)
    if reconstructed is not None:
        return reconstructed
    return _organize_xlsx_a4(source, destination, callback)


def _create_enterprise_analysis(source: Path, destination: Path, callback: ProgressCallback | None = None) -> dict[str, Any]:
    workbook = load_workbook(source, data_only=False, read_only=True)
    report = load_workbook(source, read_only=True, data_only=True)
    # Build a standalone analysis workbook.
    from openpyxl import Workbook
    out = Workbook()
    summary = out.active
    summary.title = "企业数据分析"
    headers=["工作表","有效行数","有效列数","非空单元格","公式数量","空值数量","重复行数"]
    summary.append(headers)
    for c in summary[1]:
        c.font=Font(bold=True)
        c.fill=PatternFill("solid", fgColor="DCE6F1")
        c.alignment=Alignment(horizontal="center")
    total_sheets=max(1,len(workbook.worksheets))
    totals={"rows":0,"cells":0,"formulas":0,"blanks":0,"duplicates":0}
    for idx,(ws,values_ws) in enumerate(zip(workbook.worksheets, report.worksheets), start=1):
        nonempty=0; formulas=0; blanks=0; seen=set(); duplicates=0; effective_rows=0; effective_cols=0
        for row in ws.iter_rows():
            vals=[]; row_nonempty=False
            for cell in row:
                val=cell.value; vals.append(val)
                if val not in (None, ""):
                    nonempty+=1; row_nonempty=True; effective_cols=max(effective_cols,cell.column)
                    if isinstance(val,str) and val.startswith('='): formulas+=1
                else: blanks+=1
            if row_nonempty:
                effective_rows=max(effective_rows,row[0].row if row else 0)
                key=tuple(vals[:min(len(vals),256)])
                if key in seen: duplicates+=1
                else: seen.add(key)
        summary.append([ws.title,effective_rows,effective_cols,nonempty,formulas,blanks,duplicates])
        totals["rows"]+=effective_rows; totals["cells"]+=nonempty; totals["formulas"]+=formulas; totals["blanks"]+=blanks; totals["duplicates"]+=duplicates
        _update(callback, 20 + int(idx / total_sheets * 70), "analysis_report", f"分析工作表 {idx}/{total_sheets}：{ws.title}")
    summary.append([])
    summary.append(["合计",totals["rows"],"",totals["cells"],totals["formulas"],totals["blanks"],totals["duplicates"]])
    summary.freeze_panes="A2"
    for col,width in enumerate([24,14,14,16,14,14,14], start=1): summary.column_dimensions[get_column_letter(col)].width=width
    out.save(destination)
    workbook.close(); report.close()
    return totals


def _process_file(original_name: str, stored_path: str, output_dir: Path, client: TranslationClient | None, callback: ProgressCallback | None, use_ocr: bool = False, use_cleanup: bool = False, output_options: dict[str, Any] | None = None) -> dict[str, Any]:
    source = Path(stored_path)
    suffix = source.suffix.lower()
    safe_stem = Path(original_name).stem
    cleanup_stats = None
    if suffix == ".xlsx" and use_cleanup:
        cleaned = output_dir / f"{safe_stem}_智能整理.xlsx"
        # Enterprise reconstruction changes worksheets and columns, so it is
        # only allowed when the customer explicitly selected smart data
        # organization. Translation-only Excel jobs preserve the source
        # workbook structure and write bilingual text in place.
        plc_stats = _reconstruct_plc_configuration(source, cleaned, callback)
        if plc_stats is not None:
            cleanup_stats = plc_stats
            source = cleaned
            suffix = source.suffix.lower()
        else:
            cleanup_stats = _organize_xlsx_a4(source, cleaned, callback)
            source = cleaned
            suffix = source.suffix.lower()
    if client is None and not (use_ocr and (suffix in IMAGE_SUFFIXES or suffix == ".pdf")):
        destination = output_dir / Path(source.name).name
        if source.resolve() != destination.resolve():
            shutil.copy2(source, destination)
        return {"name": destination.name, "path": str(destination), "translated_items": 0, "mode": "cleaned" if cleanup_stats else "copied", "cleanup_stats": cleanup_stats}

    # Continue translation/conversion from the cleaned workbook when requested.
    original_source_name = original_name
    suffix_label = _target_suffix(client)
    details: dict[str, Any] = {}
    if suffix in IMAGE_SUFFIXES and use_ocr:
        destination = output_dir / f"{safe_stem}_{suffix_label}.docx"
        details = _image_to_docx(source, destination, client, callback)
        count = int(details.get("translated_items") or details.get("ocr_text_blocks") or 0)
    elif suffix == ".pptx":
        destination = output_dir / f"{safe_stem}_{suffix_label}.pptx"
        count = _translate_pptx(source, destination, client, callback)
    elif suffix == ".docx":
        destination = output_dir / f"{safe_stem}_{suffix_label}.docx"
        details = _translate_docx(source, destination, client, callback)
        count = int(details.get("translated_items") or 0)
    elif suffix == ".xlsx":
        destination = output_dir / f"{safe_stem}_{suffix_label}.xlsx"
        count = _translate_xlsx(source, destination, client, callback, output_options)
    elif suffix == ".pdf":
        destination = output_dir / f"{safe_stem}_{suffix_label}.docx"
        if use_ocr:
            # First try native PDF text. If it is effectively empty, render pages and OCR them.
            reader = PdfReader(source)
            native_text = "\n".join((page.extract_text() or "") for page in reader.pages).strip()
            if len(native_text) < 20:
                details = _scanned_pdf_to_docx(source, destination, client, callback)
                count = int(details.get("translated_items") or details.get("ocr_text_blocks") or 0)
            else:
                count = _translate_pdf_to_docx(source, destination, client, callback)
        else:
            count = _translate_pdf_to_docx(source, destination, client, callback)
    else:
        destination = output_dir / Path(original_name).name
        shutil.copy2(source, destination)
        count = 0
    if cleanup_stats and source != Path(stored_path) and destination != source:
        try:
            source.unlink(missing_ok=True)
        except OSError:
            LOGGER.warning("Unable to remove intermediate safe-cleanup workbook: %s", source)
    return {"name": destination.name, "path": str(destination), "translated_items": count, "mode": "translated" if count else "copied", "cleanup_stats": cleanup_stats, **details}


def run_local_job(order: dict[str, Any], source_paths: list[tuple[str, str]], output_dir: Path, progress_callback: ProgressCallback | None = None) -> dict[str, Any]:
    """Run an order with bounded file-level concurrency.

    V13 keeps one translation client per worker so provider usage counters and
    retries remain isolated.  Single-file orders keep the original sequential
    behavior, while batch orders process up to ``BATCH_MAX_WORKERS`` files in
    parallel (default 3) to reduce total waiting time without overloading the PC
    or translation provider.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    plan = build_plan(order)
    services = order.get("services") or []
    ocr = ocr_capability()
    translation = translation_capability()
    blockers: list[str] = []
    if "translation" in services and not translation.configured:
        blockers.append(translation.message)
    if "ocr" in services and not ocr.available:
        blockers.append(ocr.message)

    _update(progress_callback, 3, "validate", "正在检查源文件完整性、大小与格式")
    if not source_paths:
        raise RuntimeError("No source files were found for this order.")
    total_bytes = 0
    format_counts: dict[str, int] = {}
    for original_name, stored_path in source_paths:
        path = Path(stored_path)
        if not path.exists() or not path.is_file():
            raise RuntimeError(f"Source file is missing: {original_name}")
        total_bytes += path.stat().st_size
        suffix = path.suffix.lower().lstrip(".") or "unknown"
        format_counts[suffix] = format_counts.get(suffix, 0) + 1
    format_summary = "、".join(f"{key.upper()} {value}个" for key, value in sorted(format_counts.items()))
    _update(
        progress_callback, 10, "validate",
        f"已校验 {len(source_paths)} 个源文件，共 {total_bytes / 1024 / 1024:.2f} MB；{format_summary}",
    )

    _update(progress_callback, 12, "analyze", "正在读取已完成的文档结构分析结果")
    analysis_data = order.get("ai_analysis") or {}
    analysis_files = analysis_data.get("files") or []
    sheet_count = 0
    formula_count = 0
    merged_count = 0
    for item in analysis_files:
        details = item.get("details") or {}
        sheet_count += int(details.get("sheet_count") or 0)
        formula_count += int(details.get("formula_count_sample") or 0)
        merged_count += int(details.get("merged_range_count") or 0)
    detected_languages = "、".join(analysis_data.get("detected_languages") or []) or "自动识别"
    category = analysis_data.get("document_category") or "文档"
    detail_parts = [f"类别：{category}", f"语言：{detected_languages}"]
    if sheet_count:
        detail_parts.append(f"工作表：{sheet_count}个")
    if formula_count:
        detail_parts.append(f"公式样本：{formula_count}个")
    if merged_count:
        detail_parts.append(f"合并区域：{merged_count}个")
    _update(progress_callback, 20, "analyze", "文档结构分析完成；" + "；".join(detail_parts))

    manifest = {
        "order_number": order["order_number"],
        "created_at": now(),
        "plan": plan,
        "ocr": ocr.__dict__,
        "translation": translation.__dict__,
        "blockers": blockers,
        "source_files": [name for name, _ in source_paths],
        "batch": {"file_count": len(source_paths)},
    }
    manifest_path = output_dir / "processing_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    if blockers:
        _update(progress_callback, 25, "configuration", blockers[0])
        return {"state": "waiting_configuration", "progress": 25, "current_step": "configuration", "plan": plan, "blockers": blockers, "manifest_path": str(manifest_path), "outputs": []}

    translation_data = order.get("translation") or {}

    shared_client: TranslationClient | None = None

    def make_client() -> TranslationClient | None:
        nonlocal shared_client
        if "translation" not in services:
            return None
        # Translation orders run sequentially by default. Reuse one client across
        # all files so repeated terms in st02-st09 are served from the same cache
        # instead of being sent to the AI provider again for every workbook.
        if shared_client is None:
            shared_client = TranslationClient(
                source_language=translation_data.get("source_language", "auto"),
                target_language=translation_data.get("target_language", "en"),
                custom_source=translation_data.get("custom_source_language", ""),
                custom_target=translation_data.get("custom_target_language", ""),
            )
            shared_client.bilingual_layout = translation_data.get("bilingual_layout") or (conversion_data.get("options") or {}).get("bilingual_layout") or "auto"
        return shared_client

    if "translation" in services:
        _update(progress_callback, 30, "translation", "AI 翻译引擎连接成功")

    total = len(source_paths)
    # Translation is network-bound and providers commonly throttle concurrent
    # requests. Running several Excel files at once can leave every worker
    # waiting on a provider timeout. Default translation batches to one worker;
    # conversion-only orders may still use the normal bounded concurrency.
    worker_env = "BATCH_TRANSLATION_MAX_WORKERS" if "translation" in services else "BATCH_MAX_WORKERS"
    worker_default = "1" if "translation" in services else "3"
    max_workers = max(1, min(int(os.getenv(worker_env, worker_default)), total, 6))
    if "translation" in services:
        max_workers = min(max_workers, max(1, int(os.getenv("TRANSLATION_FILE_WORKERS", "2"))))
    progress_lock = Lock()
    completed_count = 0
    file_fractions: dict[int, float] = {index: 0.0 for index in range(total)}
    last_reported_progress = 31
    outputs_by_index: dict[int, list[dict[str, Any]]] = {}
    usage_rows: list[dict[str, Any]] = []

    conversion_data = order.get("conversion") or {}
    output_options = conversion_data.get("options") if isinstance(conversion_data.get("options"), dict) else {}
    if translation_data.get("bilingual_layout") and not output_options.get("bilingual_layout"):
        output_options["bilingual_layout"] = translation_data.get("bilingual_layout")
    requested_formats = conversion_data.get("formats") if "conversion" in services else ["original"]
    if not isinstance(requested_formats, list) or not requested_formats:
        requested_formats = ["original"]

    def report_file_progress(index: int, original_name: str, inner_progress: int, inner_step: str, message: str) -> None:
        nonlocal last_reported_progress
        fraction = max(0.0, min(1.0, float(inner_progress) / 100.0))
        with progress_lock:
            file_fractions[index] = max(file_fractions.get(index, 0.0), fraction)
            aggregate = sum(file_fractions.values()) / max(1, total)
            mapped = 32 + int(aggregate * 53)
            mapped = max(last_reported_progress, min(85, mapped))
            last_reported_progress = mapped
        _update(progress_callback, mapped, inner_step, f"{original_name}：{message}")

    def worker(index: int, original_name: str, stored_path: str):
        started_at = time.monotonic()
        client = make_client()
        file_failures: list[dict[str, Any]] = []
        LOGGER.info("Batch worker started: index=%s file=%s", index, original_name)
        try:
            def file_progress(inner_progress: int, inner_step: str, message: str) -> None:
                # Processing/translation occupies the first 68%% of each file's
                # aggregate share. This works for both single and batch orders.
                normalized = int(max(0, min(100, inner_progress)) * 0.68)
                report_file_progress(index, original_name, normalized, inner_step, message)

            primary_step = (
                "translation" if "translation" in services else
                "ocr" if "ocr" in services else
                "cleanup" if "data_cleanup" in services else
                "conversion" if "conversion" in services else
                "analyze"
            )
            report_file_progress(index, original_name, 1, primary_step, "开始处理文件")
            primary = _process_file(
                original_name,
                stored_path,
                output_dir,
                client,
                file_progress,
                use_ocr=("ocr" in services),
                use_cleanup=("data_cleanup" in services),
                output_options=output_options,
            )
            primary_path = Path(primary["path"])
            source_suffix = Path(original_name).suffix.lower().lstrip('.')
            effective_formats = list(requested_formats)
            if 'original' in effective_formats and source_suffix == 'pdf':
                effective_formats = [('pdf' if item == 'original' else item) for item in effective_formats]
            def conversion_progress(inner_progress: int, message: str) -> None:
                # Conversion occupies the remaining 32%% of this file's share.
                normalized = 68 + int(max(0, min(100, inner_progress)) * 0.32)
                report_file_progress(index, original_name, normalized, "conversion", message)

            if "conversion" in services:
                report_file_progress(index, original_name, 69, "conversion", "正在检查是否需要转换文件类型")
                converted_paths, conversion_records = convert_outputs(
                    primary_path,
                    effective_formats,
                    output_dir,
                    progress_callback=conversion_progress,
                )
            else:
                # Translation/OCR/organization-only orders keep the processed file
                # directly. Do not create a fake conversion stage or complete the
                # translation step early by emitting a conversion event.
                converted_paths = [primary_path]
                conversion_records = [{
                    "format": "original", "status": "completed", "path": str(primary_path),
                    "message": "保持原始文件类型并保留处理后的版式",
                }]
            file_failures.extend([
                {"source_name": original_name, **item}
                for item in conversion_records if item.get("status") == "failed"
            ])
            local_outputs = []
            for converted in converted_paths:
                local_outputs.append({
                    **primary,
                    "name": converted.name,
                    "path": str(converted),
                    "output_format": converted.suffix.lower().lstrip("."),
                    "source_name": original_name,
                    "conversion_records": conversion_records,
                })
            if "enterprise_analysis" in services and Path(stored_path).suffix.lower() == ".xlsx":
                analysis_path = output_dir / f"{Path(original_name).stem}_企业数据分析.xlsx"
                analysis_stats = _create_enterprise_analysis(Path(stored_path), analysis_path, file_progress)
                local_outputs.append({
                    "name": analysis_path.name, "path": str(analysis_path), "output_format": "xlsx",
                    "source_name": original_name, "mode": "enterprise_analysis", "translated_items": 0,
                    "analysis_stats": analysis_stats, "conversion_records": []
                })
            final_file_step = "conversion" if "conversion" in services else primary_step
            report_file_progress(index, original_name, 100, final_file_step, "文件处理完成")
            LOGGER.info(
                "Batch worker completed: index=%s file=%s elapsed=%.2fs outputs=%s failures=%s",
                index, original_name, time.monotonic() - started_at, len(local_outputs), len(file_failures),
            )
            return index, local_outputs, file_failures, (client.usage_summary() if client is not None else None)
        except Exception as exc:
            failure_step = "conversion" if "conversion" in services else ("translation" if "translation" in services else "analyze")
            report_file_progress(index, original_name, 100, failure_step, f"文件失败，已隔离：{exc}")
            LOGGER.exception(
                "Batch worker failed: index=%s file=%s elapsed=%.2fs",
                index, original_name, time.monotonic() - started_at,
            )
            file_failures.append({
                "source_name": original_name, "format": "processing", "status": "failed", "error": str(exc)
            })
            return index, [], file_failures, (client.usage_summary() if client is not None else None)

    failure_rows: list[dict[str, Any]] = []
    if total == 1 or max_workers == 1:
        for index, (original_name, stored_path) in enumerate(source_paths):
            current_stage = "translation" if "translation" in services else ("ocr" if "ocr" in services else ("cleanup" if "data_cleanup" in services else "conversion"))
            _update(progress_callback, max(32, last_reported_progress), current_stage, f"当前文件 {index + 1}/{total}：{original_name}；正在准备处理")
            idx, output, failures, usage = worker(index, original_name, stored_path)
            outputs_by_index[idx] = output
            failure_rows.extend(failures)
            if usage:
                usage_rows.append(usage)
            completed_count += 1
            report_file_progress(index, original_name, 100, "conversion" if "conversion" in services else "translation", f"已完成文件 {completed_count}/{total}")
    else:
        manifest["batch"].update({"mode": "parallel", "max_workers": max_workers})
        _update(progress_callback, 32, "conversion" if "conversion" in services else "translation", f"并行批处理已启动：{total} 个文件，{max_workers} 个工作线程")
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="doc-ai") as pool:
            futures = {pool.submit(worker, i, name, path): (i, name) for i, (name, path) in enumerate(source_paths)}
            for future in as_completed(futures):
                index, original_name = futures[future]
                try:
                    idx, output, failures, usage = future.result()
                except Exception as exc:
                    idx, output, failures, usage = index, [], [{"source_name": original_name, "format": "processing", "status": "failed", "error": str(exc)}], None
                outputs_by_index[idx] = output
                failure_rows.extend(failures)
                if usage:
                    usage_rows.append(usage)
                with progress_lock:
                    completed_count += 1
                report_file_progress(index, original_name, 100, "conversion" if "conversion" in services else "translation", f"已完成文件 {completed_count}/{total}")

    outputs = [item for i in range(total) for item in outputs_by_index.get(i, [])]
    aggregate_usage = None
    if usage_rows:
        aggregate_usage = {
            "input_tokens": sum(int(r.get("input_tokens") or 0) for r in usage_rows),
            "output_tokens": sum(int(r.get("output_tokens") or 0) for r in usage_rows),
            "total_tokens": sum(int(r.get("total_tokens") or 0) for r in usage_rows),
            "estimated_cost_usd": round(sum(float(r.get("estimated_cost_usd") or 0) for r in usage_rows), 6),
            "files": len(usage_rows),
            "memory_cache_hits": sum(int(r.get("memory_cache_hits") or 0) for r in usage_rows),
            "session_cache_hits": sum(int(r.get("session_cache_hits") or 0) for r in usage_rows),
        }

    successful_output_count = len(outputs)
    failure_count = len(failure_rows)
    state, completion_message = _resolve_job_outcome(
        successful_output_count, failure_count, "manual_review" in services
    )

    # Failure details remain structured in the manifest/API. Never put an
    # error_report.txt into the customer's deliverables.
    quality_message = (
        f"质量检查通过：{successful_output_count} 个文件可交付"
        if failure_count == 0
        else f"质量检查完成：{successful_output_count} 个文件可交付，{failure_count} 项失败"
    )
    _update(progress_callback, 88, "quality", quality_message)
    if successful_output_count > 0:
        _update(progress_callback, 95, "export", f"已准备 {successful_output_count} 个交付文件")

    manifest["requested_output_formats"] = requested_formats
    manifest["outputs"] = outputs
    manifest["translation_usage"] = aggregate_usage
    manifest["failures"] = failure_rows
    manifest["partial_success"] = state == "partial_completed"
    manifest["successful_output_count"] = successful_output_count
    manifest["failure_count"] = failure_count
    manifest["terminal_state"] = state
    manifest["completed_at"] = now()
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    _update(progress_callback, 100, state, completion_message)
    return {
        "state": state, "progress": 100, "current_step": state, "plan": plan, "blockers": [],
        "manifest_path": str(manifest_path), "outputs": outputs, "translation_usage": aggregate_usage,
        "failures": failure_rows, "partial_success": state == "partial_completed",
        "successful_output_count": successful_output_count,
        "failure_count": failure_count,
        "completion_message": completion_message,
    }
